// © ALIP-AI | WhatsApp: 0812-4970-3469
// ⚠️ Do not remove this credit

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")
global.baileys = require('./package.json').dependencies['@whiskeysockets/baileys'] || 'unknown';
global.internalValidationKey = Buffer.from("LICENSE_VALIDATED").toString('base64');

// SETTING BOT
global.owner = '6288239938813'
global.versi = version
global.namaOwner = "AzzMD"
global.packname = 'Azz cute'
global.botname = 'Azz AI MD'
global.botname2 = 'Azz AI MD'

global.tempatDB = 'database.json' // Jangan ubah
global.botSecretKey = "alip-ai" // Jangan ubah

global.custompairing = "ZYRAPINK"; /* custom pairing lu */

// PAKASIR GATEWAY, GANTI PAKE PUNYA LU
global.slug = 'scorpion';
global.pkasirapikey = 'E4T3VFX0T9VgElGKidbWsQaZxITO1Rwj';

// ========= HARGA BUY PREM & SEWA BOT =========
global.harga = {
    prem: "5000",
    sewa: "10000"
}

// ======== APIKEY ALIP AI GAUSAH DI UBAH !!! ==============
global.apialip = "https://alipai-api.vercel.app"
global.btc = "https://api.botcahx.eu.org"
global.apikeyalip = "alipaiapikeybaru"
global.velyn = "https://velyn.mom"
global.apikeyvelyn = "zizzmarket"
global.yudzxml = "https://api.yydz.biz.id"
global.apikeyyud = "alipaixyudz"
global.termai = "https://api.termai.cc"
global.apitermai = "alipxtermai"

// ========PANEL SETTING !!!===============
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://" // Domain lu
global.apikey = "-" //ptla
global.capikey = "-" //ptlc
// ========================================

// Settings Link / Tautan
global.linkOwner = "https://wa.me/6288239938813"
global.linkGrup = "https://chat.whatsapp.com/JgCHcwAARqMMfywkl"

// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 3000
global.delayPushkontak = 6000

// Settings Channel / Saluran
global.linkSaluran = "https://whatsapp.com/channel/00C2W"
global.idSaluran = "123406936@newsletter"
global.namaSaluran = "💖 Azz Information || WhatsApp Bot 💖"


// Settings All Payment
global.dana = "6288239938813" // ubah jadi nomor dana kalian 
global.gopay = " blm tersedia " // ubah jadi nomor gopay kalian


// Settings Image Url
global.image = {
// gambar menu awal
menu: "https://raw.githubusercontent.com/gataubroicape-droid/dat2/main/uploads/4d3622-1768545158209.jpg",
// menu v 2
menuv2: "https://img1.pixhost.to/images/6318/608321819_media.jpg", 
//banner welcome 
welcome: "https://img1.pixhost.to/images/9307/649554070_media.jpg", 
//banner left 
left: "https://img1.pixhost.to/images/9307/649554070_media.jpg", 
// logo saat bot reply pesan
reply: "https://img1.pixhost.to/images/11205/675445331_alip-1766892626458.jpg", 
levelup: "https://img1.pixhost.to/images/9319/649726402_media.jpg", 
// ubah jadi qris kalian
qris: "https://img1.pixhost.to/images/9307/649554404_media.png"
}
// Message Command 
global.mess = {
    limit: `🎀 *Limit habis*\nSilakan ketik *.claim* untuk klaim bonus limit\nAtau *.buyprem* untuk upgrade ke Premium.`,
    owner: `🎀 *Akses ditolak*\nFitur ini hanya tersedia untuk *Owner Bot*.`,
    verifikasi: `🎀 *Akses ditolak*\nSilakan ketik *.daftar* untuk mengakses seluruh fitur bot.`,
    admin: `🎀 *Akses ditolak*\nFitur ini khusus untuk *Admin Grup*.`,
    botAdmin: `🎀 *Akses ditolak*\nBot harus menjadi *Admin Grup* untuk menjalankan fitur ini.`,
    group: `🎀 *Akses ditolak*\nFitur ini hanya dapat digunakan di dalam *Grup*.`,
    private: `🎀 *Akses ditolak*\nFitur ini hanya dapat digunakan di *Chat Pribadi*.`,
    prem: `🎀 *Akses ditolak*\nFitur ini hanya tersedia untuk *User Premium*.\nKetik *.prem* untuk informasi upgrade.`,
    wait: `🎀 *Mohon tunggu...*\nPermintaan sedang diproses.`,
    error: `🎀 *Terjadi kesalahan*\nSilakan coba kembali beberapa saat lagi.`,
    done: `🎀 *Berhasil*\nProses telah diselesaikan.`
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
