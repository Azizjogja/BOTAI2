## Rules & Guidelines
1. Dilarang keras membagikan script secara cuma cuma.
2. Penjualan ( reseller only ) upgrade reseller ke **6381249703469**
5. Jangan menghapus credit yang ada di script.  
6. Permintaan fitur untuk update diperbolehkan, selama masuk akal.  
7. Bot akan selalu diperbarui dan dikembangkan secara berkala.

# RENAME SCRIP CUKUP BAGIAN ( SETTING.JS ) DILARANG KERAS BYPASS DB BOT/ATAU MENCOPOT SISTEM DB!!!

## Cara Menjalankan Script
1. Upload file ke panel hosting.  
2. Ekstrak (unarchive) file script.  
3. Pilih Node.js versi 23 atau lebih tinggi.  
4. Masukkan password pairing yang telah diberikan.  
5. Masukkan nomor bot.

## Cara pasang backup bot supaya database lama tidak hilang 
1. Upload sc versi terbaru, lalu unarchive
2. Upload file backup kalian, lalu unarchive
3. Restart.

© 2024-2025 @alifalfrl__

## New update v10.0.0
> fokus ke fix fitur dan connection, kalo di lu masi macet macetan berarti panel lu burik kek tai

`new fitur`
___________
1. anti nsfw
2. .createhtml
3. .stalkgithub
4. .setopentime
5. .setclosetime
6. .cekjadwal
7. .copilotvoice
8. setmenu v3 v4 v5

`fix fitur`
___________
1. fakecall
2. ai
3. autoai
4. translate
5. telanjang
6. translate
7. buatgambar
8. Spotify 
9. ytmp3
10. ytmp4
11. playmusik
12. ig download image, video
13. uploader github 
14. toimg
15. setwelcome variabel date, total mem, dll
16. publicai, powerbrain, venice, webpilot, hyperai
17. tiktokstalk
18. playch
19. alipedit > maker to
20. cekcuaca
22. aiedit
23. fix sistem cpanel > plugin
24. kuismath
25. resettotalchat
26. iqc > move api alip ai
27. aio/allinone downloader 
28. .soundcloud
29. notif sholat > plugin
30. what musik

`remove fitur`
___________
1. pinvideo


 * ©alipai Since 2024 - 2026
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
