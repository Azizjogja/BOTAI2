/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 
 * Elaina AI
 * Remake By Rahmad Tenpoles
 * https://wa.me/+6285764735713
 */

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")
global.baileys = require('./package.json').dependencies['@whiskeysockets/baileys'] || 'unknown';
global.internalValidationKey = Buffer.from("LICENSE_VALIDATED").toString('base64');

// SETTING BOT
global.owner = '6288239938813'
global.versi = version
global.namaOwner = "Azz Ichsan"
global.packname = 'Alisa AI WhatsApp BOT'
global.author = 'Azz X Alisa'
global.botname = 'Alisa AI'
global.botname2 = "Alisa AI"
global.adm4 = "34.04.01.2005" // cari aja di google kode adm4 kota kalian

global.tempatDB = 'database.json' // Jangan ubah
global.botSecretKey = "alip-ai" // Jangan ubah

global.custompairing = "AAAAAAAA"; /* custom pairing lu */

// ========= HARGA =========
global.harga = {
    prem: "10000",
    sewa: "15000",
    premium: "10.000",
    sewa1minggu: "5.000",
    sewa1bulan: "15.000",
    sewa2bulan: "25.000",
    sewa3bulan: "35.000",
    sewa1tahun: "50.000",
    script: "70.000"
}

// PKASIR GATEWAY
global.slug = 'elaina'; 
global.pkasirapikey = '4IM3Siq1Frrxx9wTH667X4ASmIq3VWw1';

// ======== APIKEY ALIP AI GAUSAH DI UBAH !!! ==============
global.apialip = "https://docs-alip.clutch.web.id"
global.btc = "https://api.botcahx.eu.org"
global.apikeyalip = "alipaiapikeybaru"
global.yudzxml = "https://api.yydz.biz.id"
global.apikeyyud = "alipaixyudz"
global.termai = "https://api.termai.cc"
global.apitermai = "alipaitermai2026"
global.fgsi = "https://fgsi.dpdns.org"
global.fgsiApikey = "RahmadXElaina"

// ========PANEL SETTING !!!===============
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://xnxx.com" // Domain lu
global.apikey = "-" //ptla
global.capikey = "-" //ptlc
// ========================================

// Settings Link / Tautan
global.linkOwner = "https://wa.me/6288239938813"
global.linkGrup = "https://chat.whatsapp.com/Ha8f9o36Q6590NVeSBN1Ep?mode=gi_t"

// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 3000
global.delayPushkontak = 6000

// Settings Channel / Saluran
global.linkSaluran = "https://whatsapp.com/channel/0029Vb7XARSAu"
global.idSaluran = "1203633750@newsletter"
global.namaSaluran = "Alisa AI"


// Settings All Payment
global.dana = "-" // ubah jadi nomor dana kalian 
global.gopay = "-" // ubah jadi nomor gopay kalian


// Settings Image Url
global.image = {
// gambar menu awal
menu: "https://files.catbox.moe/5m6yut.jpg", 
// menu v 2
menuv2: "https://files.catbox.moe/5m6yut.jpg", 
menuv3: "https://files.catbox.moe/5m6yut.jpg",
//banner welcome
welcome: "http://aliceecdn.vercel.app/file/991838cc8b.png",
//banner left 
left: "http://aliceecdn.vercel.app/file/fb4fc72b03.png", 
// logo saat bot reply pesan
reply: "https://img2.pixhost.to/images/6261/702365208_alip-1772897662768.jpg", 
levelup: "https://nauval.cloud/download/alip-1766031972731.jpg", 
canvas: "https://img1.pixhost.to/images/9319/649726402_media.jpg", 
// ubah jadi qris kalian
qris: "./library/qris.jpg"
}
// Message Command 
global.mess = {
    limit: `❌ *Limit habis!*\n\nKetik *.claim* untuk claim limit bonus\n*.buyprem* untuk upgrade premium`,
    owner: `🚫 *AKSES DITOLAK*\nFitur ini hanya bisa digunakan oleh *Owner Bot*.`,
    verifikasi: `🚫 *AKSES DITOLAK*\nSilahkan ketik *.daftar* untuk akses semua fitur bot.`,
    admin: `🚫 *AKSES DITOLAK*\nFitur ini khusus untuk *Admin Grup*.`,
    botAdmin: `🚫 *AKSES DITOLAK*\nBot harus menjadi *Admin Grup* terlebih dahulu untuk menjalankan fitur ini.`,
    group: `🚫 *AKSES DITOLAK*\nFitur ini hanya dapat digunakan di *dalam grup*.`,
    private: `🚫 *AKSES DITOLAK*\nFitur ini hanya bisa digunakan di *chat pribadi*.`,
    prem: `🚫 *AKSES DITOLAK*\nFitur ini hanya tersedia untuk *User Premium*.\n> ketik .prem dan upgrade nomor mu`,
    wait: `⏳ *Mohon tunggu...*\nPermintaan kamu sedang diproses.`,
    error: `❌ *Terjadi kesalahan!*\nSilakan coba lagi nanti.`,
    done: `✅ *Berhasil!*\nProses telah selesai dengan sukses.`
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
