const fs = require('fs')
const dbAlarm = './library/database/alarm.json'

if (!fs.existsSync(dbAlarm)) {
    const dbDir = './library/database'
    if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true })
    fs.writeFileSync(dbAlarm, JSON.stringify({}, null, 2))
}

const runAlarm = async () => {
    if (!global.alipInstance) return
    const alip = global.alipInstance
    
    let alarms = {}
    try {
        const data = fs.readFileSync(dbAlarm, 'utf-8')
        alarms = JSON.parse(data)
    } catch (e) {
        return
    }

    const now = new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" })
    const waktuSekarang = new Date(now)
    const jamMenit = waktuSekarang.getHours().toString().padStart(2, '0') + ':' + waktuSekarang.getMinutes().toString().padStart(2, '0')
    const hariIni = waktuSekarang.toDateString()

    let isChanged = false
    for (let jid in alarms) {
        let groupAlarms = alarms[jid]
        for (let alarm of groupAlarms) {
            if (alarm.active && alarm.time === jamMenit && alarm.lastSent !== hariIni) {
                try {
                    const metadata = await alip.groupMetadata(jid).catch(() => null)
                    if (!metadata) continue
                    const participants = metadata.participants.map(v => v.id)
                    
                    await alip.sendMessage(jid, {
                        text: `🔔 *Notifikasi Alarm Grup*\n\npesan: ${alarm.msg}\nwaktu: ${alarm.time} wib`,
                        contextInfo: {
                            mentionedJid: participants,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.idSaluran,
                                newsletterName: global.namaSaluran,
                                serverMessageId: -1
                            },
                            externalAdReply: {
                                title: `🔊 Alarm Berdering`,
                                body: `${alarm.time} wib`,
                                thumbnailUrl: global.image.menu,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    })
                    alarm.lastSent = hariIni
                    isChanged = true
                } catch (e) {}
            }
        }
    }
    if (isChanged) fs.writeFileSync(dbAlarm, JSON.stringify(alarms, null, 2))
}

if (!global.alarmInterval) {
    global.alarmInterval = setInterval(runAlarm, 10000)
}

let handler = async (m, { alip, command, isCreator, Reply, text, prefix }) => {
    global.alipInstance = alip
    
    if (!m.isGroup) return Reply('fitur ini cuma bisa di grup kak')
    if (!m.isAdmin && !isCreator) return Reply('khusus admin grup ya kak')
    
    let alarms = {}
    try {
        alarms = JSON.parse(fs.readFileSync(dbAlarm, 'utf-8'))
    } catch (e) {
        alarms = {}
    }
    
    if (!alarms[m.chat]) alarms[m.chat] = []
    const args = text.split(' ')
    const action = args[0]?.toLowerCase()

    if (action === 'add') {
        if (alarms[m.chat].length >= 5) return Reply('maximal cuma bisa 5 alarm per grup kak')
        const content = text.replace('add', '').trim()
        if (!content.includes('|')) return Reply(`formatnya: ${prefix}alarm add pesan|14:00`)
        const [pesan, waktu] = content.split('|')
        if (!/^([0-1]?[0-9]|2[0-3]):([0-5][0-9])$/.test(waktu.trim())) return Reply('format waktu salah kak, harus hh:mm')
        
        alarms[m.chat].push({
            msg: pesan.trim(),
            time: waktu.trim(),
            active: true,
            lastSent: ''
        })
        fs.writeFileSync(dbAlarm, JSON.stringify(alarms, null, 2))
        Reply(`berhasil nambahin alarm jam ${waktu.trim()} kak`)
    } 
    else if (action === 'delete') {
        const target = args[1]
        if (!target) return Reply('masukin jam yang mau dihapus kak')
        const index = alarms[m.chat].findIndex(v => v.time === target)
        if (index === -1) return Reply('jam itu nggak ada di daftar alarm kak')
        alarms[m.chat].splice(index, 1)
        fs.writeFileSync(dbAlarm, JSON.stringify(alarms, null, 2))
        Reply(`alarm jam ${target} udah dihapus ya kak`)
    }
    else if (action === 'on') {
        const target = args[1]
        if (!target) return Reply('masukin jam yang mau diaktifin kak')
        const alarm = alarms[m.chat].find(v => v.time === target)
        if (!alarm) return Reply('alarm nggak ketemu kak')
        alarm.active = true
        fs.writeFileSync(dbAlarm, JSON.stringify(alarms, null, 2))
        Reply(`alarm jam ${target} sekarang aktif kak`)
    }
    else if (action === 'off') {
        const target = args[1]
        if (!target) return Reply('masukin jam yang mau dimatiin kak')
        const alarm = alarms[m.chat].find(v => v.time === target)
        if (!alarm) return Reply('alarm nggak ketemu kak')
        alarm.active = false
        fs.writeFileSync(dbAlarm, JSON.stringify(alarms, null, 2))
        Reply(`alarm jam ${target} udah dinonaktifkan kak`)
    }
    else if (action === 'cek') {
        if (alarms[m.chat].length === 0) return Reply('grup ini belum punya alarm kak')
        let txt = `📊 *daftar alarm grup*\n\n`
        alarms[m.chat].forEach((v, i) => {
            txt += `${i + 1}. [${v.active ? '✅' : '❌'}] ${v.time}\n   pesan: ${v.msg}\n\n`
        })
        Reply(txt.trim())
    }
    else {
        Reply(`pilih opsi yang bener kak\n\ncontoh:\n${prefix}alarm add pesan|14:00\n${prefix}alarm delete 14:00\n${prefix}alarm on 14:00\n${prefix}alarm off 14:00\n${prefix}alarm cek`)
    }
}

handler.command = ['alarm']
module.exports = handler