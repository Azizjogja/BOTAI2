/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const axios = require('axios')
const FormData = require('form-data')
const Jimp = require('jimp')
const fakeUserAgent = require('fake-useragent')
const https = require('https')

const agent = new https.Agent({ rejectUnauthorized: false })

function getPrompt(nama, role) {
    return `Buat poster esports sinematik yang menampilkan pro player MLBB. pose keren dan arogan dengan tangan kanan menunjuk kedepan dan tangan kiri sedikit dilipat, dan kepala sedikit terangkat, menunjukkan dominasi dan kepercayaan diri. Subjek mengenakan jersey Evos Esports dan memakai lengan hitam panjang. Dengan Latar Belakang: - Gradien dari hitam ke kuning. - Ilustrasi logo semi-transparan berukuran besar (GOLDLANE) Ditempatkan di belakang subjek, sedikit memudar namun dramatis. - Tambahkan suar pencahayaan dinamis, lampu sorot di atas kepala seperti arena panggung, efek asap halus di sekitar bagian bawah, dan siluet yang samar-samar terlihat untuk menciptakan suasana. - Sertakan bentuk grafis diagonal berwarna kuning dan putih (garis-garis, fragmen, dan garis abstrak) untuk menciptakan nuansa poster olahraga yang dramatis. Elemen Teks: - Tag gamer "${nama}" di tengah poster, sangat besar, hanya garis luar putih (tanpa isian), tipografi tebal dan modern. - Tambahkan teks role "${role}" di bagian bawah dengan font lebih kecil namun tetap tegas. Gaya: Poster olahraga sinematik beresolusi tinggi yang sangat realistis. Tata letaknya energik, dramatis, dan penuh atmosfer esports (tidak terlalu minimalis). Rasio aspeknya 3:4.`
}

let handler = async (m, { alip, command, isCreator, isPremium, Reply, text, prefix }) => {
    if (!isCreator && !isPremium) return Reply(global.mess.prem)

    if (!global.polaroidSessions) global.polaroidSessions = {}

    const key = `${m.chat}:${m.sender}`
    const q = m.quoted || m
    const mime = (q.msg || q).mimetype || ''

    if (!global.polaroidSessions[key]) {
        if (!text) return Reply(`📌 *Contoh:* .${command} Nama|Role\n\n*Contoh:* .${command} EVOS ALSKIE|Gold Lane`)

        const [nama, role] = text.split('|').map(v => v.trim())
        if (!nama || !role) return Reply('❌ Format salah! Gunakan: Nama|Role')

        if (!/image\//i.test(mime)) {
            return Reply(`❌ Balas *gambar pertama* (foto muka) dengan caption *${prefix + command} ${nama}|${role}*`)
        }

        const buf1 = await q.download()
        if (!buf1) return Reply('Gagal download gambar pertama.')

        global.polaroidSessions[key] = { 
            buf1, 
            nama, 
            role,
            prompt: getPrompt(nama, role)
        }

        return m.reply(
            `✅ Foto pertama (muka) disimpan untuk *${nama} - ${role}*\n` +
            `Sekarang balas *gambar kedua* (foto baju) dengan caption *${prefix + command}* lagi.\n\n` +
            'Ketik *.batalposter* untuk membatalkan.'
        )
    }

    const sess = global.polaroidSessions[key]
    if (!/image\//i.test(mime)) {
        return Reply(`❌ Balas *gambar kedua* (foto baju) dengan caption *${prefix + command}*`)
    }

    try {
        await alip.sendMessage(m.chat, { react: { text: '🔄', key: m.key } })
        await m.reply(`⏳ Membuat poster untuk *${sess.nama} - ${sess.role}*...`)

        const buf2 = await q.download()
        if (!buf2) return Reply('Gagal download gambar kedua.')

        const merged = await mergePhotos(sess.buf1, buf2)
        const mergedUrl = await uploadUguu(merged, 'merged.jpg')

        const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikeyalip}&url=${encodeURIComponent(mergedUrl)}&prompt=${encodeURIComponent(sess.prompt)}`
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' })
        const hasilBuffer = Buffer.from(response.data)

        await alip.sendMessage(m.chat, {
            image: hasilBuffer,
            caption: `✅ *Poster Esports Selesai!*\n\n👤 *Player:* ${sess.nama}\n🎮 *Role:* ${sess.role}`
        }, { quoted: m })

        await alip.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
    } catch (e) {
        await Reply(`❌ Error: ${e.message}`)
    } finally {
        delete global.polaroidSessions[key]
    }
}

async function uploadUguu(buffer, filename = 'file.jpg') {
    const form = new FormData()
    form.append('files[]', buffer, { filename, contentType: 'application/octet-stream' })
    const { data } = await axios.post('https://uguu.se/upload.php', form, {
        headers: { ...form.getHeaders(), 'User-Agent': fakeUserAgent() },
        httpsAgent: agent,
        maxBodyLength: Infinity,
        timeout: 60000
    })
    const url = data?.files?.[0]?.url
    if (!url) throw new Error('Upload ke Uguu gagal')
    return url
}

async function mergePhotos(buf1, buf2) {
    const img1 = await Jimp.read(buf1)
    const img2 = await Jimp.read(buf2)
    const size = 700
    img1.cover(size, size)
    img2.cover(size, size)
    const gap = 20
    const canvas = new Jimp(size * 2 + gap, size, 0xffffffff)
    canvas.composite(img1, 0, 0)
    canvas.composite(img2, size + gap, 0)
    return await canvas.getBufferAsync(Jimp.MIME_JPEG)
}

handler.before = async (m, { alip }) => {
    if (m.text?.toLowerCase() === '.batalposter' && global.polaroidSessions?.[`${m.chat}:${m.sender}`]) {
        delete global.polaroidSessions[`${m.chat}:${m.sender}`]
        await alip.sendMessage(m.chat, { text: '✅ Sesi poster dibatalkan.' }, { quoted: m })
        return true
    }
    return false
}

handler.command = ['poster', 'posteresports', 'evosposter']

module.exports = handler