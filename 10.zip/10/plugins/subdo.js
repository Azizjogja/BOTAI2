/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const axios = require('axios')
if (!global.db) global.db = {}
if (!global.db.cfSubdomains) global.db.cfSubdomains = {}
if (!global.db.cfStats) global.db.cfStats = { total: 0, lastSync: null }

function saveToDatabase() {
    try {
        const fs = require('fs')
        fs.writeFileSync('./library/database/db.json', JSON.stringify(global.db, null, 2))
    } catch (e) {
        console.error('Gagal menyimpan database:', e)
    }
}

async function syncWithCloudflare(zoneId, apiToken) {
    try {
        const { data } = await axios.get(
            `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records?per_page=100`,
            {
                headers: {
                    'Authorization': `Bearer ${apiToken}`,
                    'Content-Type': 'application/json'
                }
            }
        )

        if (!data.success) return false

        // Reset database untuk sinkronisasi
        global.db.cfSubdomains = {}
        global.db.cfSubdomains.records = []

        for (const record of data.result) {
            if (record.type === 'A') {
                global.db.cfSubdomains.records.push({
                    subdomain: record.name,
                    ip: record.content,
                    recordId: record.id,
                    proxied: record.proxied,
                    ttl: record.ttl,
                    createdOn: record.created_on,
                    modifiedOn: record.modified_on
                })
            }
        }

        global.db.cfStats.lastSync = new Date().toISOString()
        global.db.cfStats.total = global.db.cfSubdomains.records?.length || 0
        saveToDatabase()
        return true
    } catch (error) {
        console.error('Sync error:', error)
        return false
    }
}

let handler = async (m, { alip, text, command, isCreator, Reply, example }) => {
    if (!isCreator) return Reply(global.mess.owner)

    const zoneId = global.cloudflareZoneId
    const apiToken = global.cloudflareApiToken
    const domain = global.cloudflareDomain

    if (!zoneId || !apiToken || !domain) {
        return Reply('❌ Konfigurasi Cloudflare belum diatur di settings.js\n\nTambahkan:\ncloudflareZoneId = "your_zone_id"\ncloudflareApiToken = "your_api_token"\ncloudflareDomain = "example.com"')
    }
    if (command === 'listsubdomain' || command === 'listsubdo' || command === 'lsd') {
        await alip.sendMessage(m.chat, { react: { text: '📋', key: m.key } })

        try {
            await syncWithCloudflare(zoneId, apiToken)

            const records = global.db.cfSubdomains.records || []
            
            if (records.length === 0) {
                return Reply('📭 Belum ada subdomain yang terdaftar.')
            }

            let message = `📋 *DAFTAR SUBDOMAIN*\n`
            message += `📅 Total: ${records.length}\n`
            message += `🔄 Last Sync: ${global.db.cfStats.lastSync ? new Date(global.db.cfStats.lastSync).toLocaleString('id-ID') : 'Never'}\n\n`

            records.sort((a, b) => new Date(b.createdOn) - new Date(a.createdOn))

            records.forEach((record, index) => {
                message += `${index + 1}. *${record.subdomain}*\n`
                message += `   ├ IP: ${record.ip}\n`
                message += `   ├ Proxy: ${record.proxied ? '✅' : '❌'}\n`
                message += `   ├ TTL: ${record.ttl === 1 ? 'Auto' : record.ttl + 's'}\n`
                message += `   ├ Created: ${new Date(record.createdOn).toLocaleDateString('id-ID')}\n`
                message += `   └ ID: ${record.recordId}\n\n`
            })

            await alip.sendMessage(m.chat, { text: message }, { quoted: m })
            await alip.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

        } catch (error) {
            console.error('[LIST ERROR]', error)
            await alip.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
            Reply(`❌ Gagal mengambil daftar: ${error.message}`)
        }
        return
    }
    if (command === 'delsubdomain' || command === 'delsubdo' || command === 'dsd') {
        if (!text) return Reply(`📌 *Contoh:*\n.${command} panel\n.${command} panel.alipai.my.id\n.${command} recordId`)

        await alip.sendMessage(m.chat, { react: { text: '🗑️', key: m.key } })

        try {
            await syncWithCloudflare(zoneId, apiToken)

            const records = global.db.cfSubdomains.records || []
            let targetRecord = null
            let searchTerm = text.toLowerCase()
            if (searchTerm.includes('.')) {
                targetRecord = records.find(r => r.subdomain.toLowerCase() === searchTerm)
            } else if (searchTerm.length > 20) {
                targetRecord = records.find(r => r.recordId === searchTerm)
            } else {
                targetRecord = records.find(r => r.subdomain.split('.')[0].toLowerCase() === searchTerm)
            }

            if (!targetRecord) {
                return Reply(`❌ Subdomain *${text}* tidak ditemukan!\nGunakan .listsubdomain untuk melihat daftar.`)
            }
            const deleteRes = await axios.delete(
                `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records/${targetRecord.recordId}`,
                {
                    headers: {
                        'Authorization': `Bearer ${apiToken}`,
                        'Content-Type': 'application/json'
                    }
                }
            )

            if (!deleteRes.data.success) {
                throw new Error(deleteRes.data.errors[0]?.message || 'Gagal menghapus')
            }
            global.db.cfSubdomains.records = records.filter(r => r.recordId !== targetRecord.recordId)
            global.db.cfStats.total = global.db.cfSubdomains.records.length
            saveToDatabase()

            const caption = `✅ *SUBDOMAIN BERHASIL DIHAPUS*

📌 Domain: ${targetRecord.subdomain}
🌐 IP: ${targetRecord.ip}
🆔 Record ID: ${targetRecord.recordId}
📅 Created: ${new Date(targetRecord.createdOn).toLocaleString('id-ID')}

📝 *DNS record telah dihapus dari Cloudflare.*`

            await alip.sendMessage(m.chat, { text: caption }, { quoted: m })
            await alip.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

        } catch (error) {
            console.error('[DELETE ERROR]', error)
            await alip.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
            Reply(`❌ Gagal menghapus: ${error.message}`)
        }
        return
    }
    if (command === 'syncsubdo' || command === 'sync') {
        await alip.sendMessage(m.chat, { react: { text: '🔄', key: m.key } })

        try {
            const success = await syncWithCloudflare(zoneId, apiToken)
            
            if (success) {
                const records = global.db.cfSubdomains.records || []
                Reply(`✅ *Sinkronisasi berhasil!*\n\n📊 Total subdomain: ${records.length}\n🕐 Last sync: ${global.db.cfStats.lastSync}`)
            } else {
                Reply('❌ Gagal sinkronisasi dengan Cloudflare!')
            }
            
            await alip.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

        } catch (error) {
            console.error('[SYNC ERROR]', error)
            await alip.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
            Reply(`❌ Gagal sinkronisasi: ${error.message}`)
        }
        return
    }
    if (command === 'infosubdo' || command === 'infosubdomain') {
        if (!text) return Reply(`📌 *Contoh:*\n.${command} panel\n.${command} panel.alipai.my.id`)

        await alip.sendMessage(m.chat, { react: { text: '🔍', key: m.key } })

        try {
            await syncWithCloudflare(zoneId, apiToken)

            const records = global.db.cfSubdomains.records || []
            let targetRecord = null
            let searchTerm = text.toLowerCase()

            if (searchTerm.includes('.')) {
                targetRecord = records.find(r => r.subdomain.toLowerCase() === searchTerm)
            } else {
                targetRecord = records.find(r => r.subdomain.split('.')[0].toLowerCase() === searchTerm)
            }

            if (!targetRecord) {
                return Reply(`❌ Subdomain *${text}* tidak ditemukan!`)
            }

            const message = `📋 *INFORMASI SUBDOMAIN*

📌 Domain: ${targetRecord.subdomain}
🌐 IP Address: ${targetRecord.ip}
🆔 Record ID: ${targetRecord.recordId}
🛡️ Proxied: ${targetRecord.proxied ? '✅ (CDN Aktif)' : '❌ (Langsung ke IP)'}
⏱️ TTL: ${targetRecord.ttl === 1 ? 'Auto' : targetRecord.ttl + ' seconds'}
📅 Dibuat: ${new Date(targetRecord.createdOn).toLocaleString('id-ID')}
📅 Dimodifikasi: ${new Date(targetRecord.modifiedOn).toLocaleString('id-ID')}

🔗 *URL Akses:*
• http://${targetRecord.subdomain}
• https://${targetRecord.subdomain} ${targetRecord.proxied ? '(Aktif)' : '(Nonaktif, aktifkan proxied)'}`

            await alip.sendMessage(m.chat, { text: message }, { quoted: m })
            await alip.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

        } catch (error) {
            console.error('[INFO ERROR]', error)
            await alip.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
            Reply(`❌ Gagal mengambil info: ${error.message}`)
        }
        return
    }
    if (!text) return Reply(`📌 *Contoh penggunaan:*\n.${command} subdomain|ip:port\n\n*Contoh:*\n.${command} panel|192.168.1.100:3000`)

    const args = text.split('|')
    if (args.length < 2) return Reply('❌ Format salah! Gunakan: subdomain|ip:port')

    const [subdomain, target] = args.map(v => v.trim())
    const [ip, port] = target.split(':')

    if (!ip || !port) return Reply('❌ Format target salah! Gunakan ip:port')

    await alip.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    try {
        const fullDomain = `${subdomain}.${domain}`
        const checkRes = await axios.get(
            `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records?name=${fullDomain}`,
            {
                headers: {
                    'Authorization': `Bearer ${apiToken}`,
                    'Content-Type': 'application/json'
                }
            }
        )

        if (checkRes.data.result.length > 0) {
            return Reply(`❌ Subdomain *${fullDomain}* sudah terdaftar!`)
        }
        const createRes = await axios.post(
            `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`,
            {
                type: 'A',
                name: subdomain,
                content: ip,
                ttl: 120,
                proxied: false
            },
            {
                headers: {
                    'Authorization': `Bearer ${apiToken}`,
                    'Content-Type': 'application/json'
                }
            }
        )

        if (!createRes.data.success) {
            throw new Error(createRes.data.errors[0]?.message || 'Gagal membuat DNS record')
        }

        const recordId = createRes.data.result.id
        if (!global.db.cfSubdomains.records) global.db.cfSubdomains.records = []

        global.db.cfSubdomains.records.push({
            subdomain: fullDomain,
            ip: ip,
            port: port,
            recordId: recordId,
            proxied: false,
            ttl: 120,
            createdOn: new Date().toISOString(),
            modifiedOn: new Date().toISOString()
        })

        global.db.cfStats.total = global.db.cfSubdomains.records.length
        saveToDatabase()

        const caption = `✅ *SUBDOMAIN BERHASIL DIBUAT*

📌 *Domain:* ${fullDomain}
🌐 *Target:* ${ip}:${port}
🆔 *Record ID:* ${recordId}
⏱️ *TTL:* 120 seconds

🔗 *Akses:* http://${fullDomain}
🔒 *SSL:* https://${fullDomain} (aktifkan proxied=true untuk SSL)

📝 *Command Lainnya:*
• .listsubdomain - Lihat semua subdomain
• .infosubdo ${subdomain} - Info detail subdomain
• .delsubdo ${subdomain} - Hapus subdomain
• .syncsubdo - Sinkronisasi dengan Cloudflare`

        await alip.sendMessage(m.chat, { text: caption }, { quoted: m })
        await alip.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

    } catch (error) {
        console.error('[CLOUDFLARE ERROR]', error)
        await alip.sendMessage(m.chat, { react: { text: '❌', key: m.key } })

        if (error.response) {
            Reply(`❌ Cloudflare API Error: ${error.response.data.errors[0]?.message || error.message}`)
        } else {
            Reply(`❌ Gagal: ${error.message}`)
        }
    }
}

handler.command = ['cfsub', 'subdo', 'createsubdo', 'listsubdomain', 'listsubdo', 'lsd', 'delsubdomain', 'delsubdo', 'dsd', 'syncsubdo', 'sync', 'infosubdo', 'infosubdomain']

module.exports = handler