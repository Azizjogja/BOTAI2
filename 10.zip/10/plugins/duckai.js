/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const axios = require('axios')

let handler = async (m, { alip, text, command, isCreator, isPremium, Reply, example }) => {
    if (!isCreator && !isPremium) return Reply(global.mess.prem)
    
    if (!text) return Reply(`📌 *Contoh penggunaan:*\n.${command} kucing terbang di angkasa`)

    await alip.sendMessage(m.chat, { react: { text: '🎨', key: m.key } })

    try {
        const apiUrl = `https://api.siputzx.my.id/api/ai/duckaiimage?prompt=${encodeURIComponent(text)}`
        
        const response = await axios.get(apiUrl, { 
            timeout: 60000
        })

        if (!response.data.status || !response.data.data?.url) {
            throw new Error('Gagal mendapatkan gambar')
        }

        const imageUrl = response.data.data.url
        const width = response.data.data.width || 1024
        const height = response.data.data.height || 1536

        await alip.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: `✅ *Gambar Berhasil Dibuat*\n\n📝 *Prompt:* ${text}\n📐 *Ukuran:* ${width}x${height}`
        }, { quoted: m })

        await alip.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

    } catch (error) {
        console.error('[DUCKAI ERROR]', error)
        await alip.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        
        if (error.response?.status === 404) {
            Reply('❌ API tidak ditemukan!')
        } else if (error.code === 'ECONNABORTED') {
            Reply('⏱️ Timeout, coba lagi nanti!')
        } else {
            Reply(`❌ Gagal: ${error.message}`)
        }
    }
}

handler.command = ['duckai', 'duckaiimage', 'dai']
handler.help = ['duckai <prompt>']
handler.tags = ['ai', 'maker']
handler.premium = true

module.exports = handler