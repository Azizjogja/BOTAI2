// AUTO REACT RANDOM (khusus owner) — YNA STORE

let handler = async (m, { alip }) => {
  // ganti nomor kalian awalan 628xxxxxxxxxx
  if (m.sender !== "6288239938813@s.whatsapp.net") return;

  // anti spam: jangan react ke pesan bot sendiri / atau event kosong
  if (m.fromMe) return;

  const emo = pickRandom(EMOJIS);

  try {
    await alip.sendMessage(m.chat, {
      react: { text: emo, key: m.key },
    });
  } catch {}
};

// hook untuk semua pesan masuk
handler.before = handler;

// command array kosong biar aman di loader yang cek plugin.command.find
handler.command = [];

module.exports = handler;

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

const EMOJIS = [
  // love
  "♥️","❤️","🧡","💛","💚","🩵","💙","💜","🤎","🖤","🩶","🩷",
  "💘","💝","💖","💗","💓","💞","💕","💌","💟","❣️","❤️‍🩹","❤️‍🔥","💋","🫶","🌹",

  // fun / meme
  "🗿","😹","😂","🤣","😭","🥹","😎","🤝","🔥","⚡","✨","⭐","🌟","💥",
  "🤡","🫡","🥶","🤯","😈","👑","💸","🤑","✅","🧠","🫰","🤌","💯",

  // random cute
  "🐱","🐶","🐼","🦊","🐸","🐣","🦋","🍀","🍓","🍭","🍜","🍔","☕","🧋",
];