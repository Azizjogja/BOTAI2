/*
 * Plugin: Jadwal Open/Close Otomatis Grup
 * Author: ALIP-AI
 * Since: 2024 - 2026
 */

const fs = require('fs')
const dbPath = './library/database/database.json'

const syncDB = () => {
    try {
        const dbDir = './library/database'
        if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true })
        
        if (!fs.existsSync(dbPath)) {
            fs.writeFileSync(dbPath, JSON.stringify({ groups: {}, settings: {} }, null, 2))
        }

        const fileData = JSON.parse(fs.readFileSync(dbPath, 'utf8'))
        
        if (!global.db) {
            global.db = fileData
        } else {
            if (!global.db.groups) global.db.groups = {}
            global.db.groups = { ...fileData.groups, ...global.db.groups }
        }
        return global.db
    } catch (e) {
        return global.db || { groups: {} }
    }
}

const saveToFile = () => {
    try {
        fs.writeFileSync(dbPath, JSON.stringify(global.db, null, 2))
    } catch (e) {
        console.error('Gagal simpan database:', e)
    }
}

if (!global.scheduleCheckerStarted) {
    setInterval(async () => {
        try {
            syncDB()
            if (!global.db?.groups) return

            const now = new Date()
            const wib = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }))
            const jam = wib.getHours()
            const menit = wib.getMinutes()
            const hariIni = wib.toDateString()
            
            const alipInstance = global.alipInstance
            if (!alipInstance) return

            let updated = false

            for (const id in global.db.groups) {
                const data = global.db.groups[id]

                if (data.closeActive && data.closeSchedule) {
                    const [h, m] = data.closeSchedule.split(':').map(Number)
                    if (jam === h && menit === m && data.lastClose !== hariIni) {
                        try {
                            await alipInstance.groupSettingUpdate(id, 'announcement')
                            global.db.groups[id].lastClose = hariIni
                            updated = true
                            await alipInstance.sendMessage(id, {
                                text: `🔒 *GRUP DITUTUP OTOMATIS*\n\nSesuai jadwal pukul ${data.closeSchedule}\nSekarang hanya admin yang dapat mengirim pesan.`
                            }).catch(() => {})
                        } catch (e) {}
                    }
                }

                if (data.openActive && data.openSchedule) {
                    const [h, m] = data.openSchedule.split(':').map(Number)
                    if (jam === h && menit === m && data.lastOpen !== hariIni) {
                        try {
                            await alipInstance.groupSettingUpdate(id, 'not_announcement')
                            global.db.groups[id].lastOpen = hariIni
                            updated = true
                            await alipInstance.sendMessage(id, {
                                text: `🔓 *GRUP DIBUKA OTOMATIS*\n\nSesuai jadwal pukul ${data.openSchedule}\nSekarang semua member dapat mengirim pesan.`
                            }).catch(() => {})
                        } catch (e) {}
                    }
                }
            }

            if (updated) saveToFile()
        } catch (e) {}
    }, 10000)
    global.scheduleCheckerStarted = true
}

let handler = async (m, { alip, command, isCreator, Reply, text }) => {
    global.alipInstance = alip
    const prefix = '.'
    
    syncDB()
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}

    if (command === 'setclosetime') {
        if (!m.isGroup) return Reply('❌ Hanya untuk grup!')
        if (!m.isAdmin && !isCreator) return Reply('❌ Admin only!')
        if (!m.isBotAdmin) return Reply('❌ Bot bukan admin!')

        if (!text) {
            const jadwal = global.db.groups[m.chat].closeSchedule
            const status = global.db.groups[m.chat].closeActive
            return Reply(`📅 *JADWAL CLOSE*\n\nSaat ini: ${jadwal || '❌'}\nStatus: ${status ? '✅' : '❌'}\n\n📌 Gunakan:\n• ${prefix}setclosetime 23:00\n• ${prefix}setclosetime off\n• ${prefix}setclosetime on`)
        }

        if (text === 'off') {
            global.db.groups[m.chat].closeActive = false
            saveToFile()
            return Reply('✅ Close OFF')
        }

        if (text === 'on') {
            if (!global.db.groups[m.chat].closeSchedule) return Reply('❌ Set jam dulu!')
            global.db.groups[m.chat].closeActive = true
            saveToFile()
            return Reply(`✅ Close ON: ${global.db.groups[m.chat].closeSchedule}`)
        }

        if (!/^([0-1]?[0-9]|2[0-3]):([0-5][0-9])$/.test(text)) return Reply('❌ Format HH:MM!')

        global.db.groups[m.chat].closeSchedule = text
        global.db.groups[m.chat].closeActive = true
        saveToFile()
        Reply(`✅ Close set: ${text}`)

    } else if (command === 'setopentime') {
        if (!m.isGroup) return Reply('❌ Hanya untuk grup!')
        if (!m.isAdmin && !isCreator) return Reply('❌ Admin only!')
        if (!m.isBotAdmin) return Reply('❌ Bot bukan admin!')

        if (!text) {
            const jadwal = global.db.groups[m.chat].openSchedule
            const status = global.db.groups[m.chat].openActive
            return Reply(`📅 *JADWAL OPEN*\n\nSaat ini: ${jadwal || '❌'}\nStatus: ${status ? '✅' : '❌'}\n\n📌 Gunakan:\n• ${prefix}setopentime 05:00\n• ${prefix}setopentime off\n• ${prefix}setopentime on`)
        }

        if (text === 'off') {
            global.db.groups[m.chat].openActive = false
            saveToFile()
            return Reply('✅ Open OFF')
        }

        if (text === 'on') {
            if (!global.db.groups[m.chat].openSchedule) return Reply('❌ Set jam dulu!')
            global.db.groups[m.chat].openActive = true
            saveToFile()
            return Reply(`✅ Open ON: ${global.db.groups[m.chat].openSchedule}`)
        }

        if (!/^([0-1]?[0-9]|2[0-3]):([0-5][0-9])$/.test(text)) return Reply('❌ Format HH:MM!')

        global.db.groups[m.chat].openSchedule = text
        global.db.groups[m.chat].openActive = true
        saveToFile()
        Reply(`✅ Open set: ${text}`)

    } else if (command === 'cekjadwal') {
        if (!m.isGroup) return Reply('❌ Hanya di grup!')
        const g = global.db.groups[m.chat] || {}
        Reply(`📊 *JADWAL GRUP*\n\n🔒 Close: ${g.closeSchedule || '❌'}\nStatus: ${g.closeActive ? '✅' : '❌'}\n\n🔓 Open: ${g.openSchedule || '❌'}\nStatus: ${g.openActive ? '✅' : '❌'}`)
    }
}

handler.command = ["setclosetime", "setopentime", "cekjadwal"]
module.exports = handler