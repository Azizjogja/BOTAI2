const fs = require('fs')

const jadwalSholat = {
Subuh:"04:27",
Dzuhur:"12:02",
Ashar:"15:23",
Maghrib:"18:00",
Isya:"19:12"
}

const dbPath='./library/database/sholat_db.json'

if(!fs.existsSync(dbPath)){
const dbDir='./library/database'
if(!fs.existsSync(dbDir)) fs.mkdirSync(dbDir,{recursive:true})
fs.writeFileSync(dbPath,JSON.stringify({active:true,lastSent:{}},null,2))
}

function loadDB(){
return JSON.parse(fs.readFileSync(dbPath))
}

function saveDB(data){
fs.writeFileSync(dbPath,JSON.stringify(data,null,2))
}

if(!global.sholatCheckerStarted){
setInterval(async()=>{
try{
const db=loadDB()
if(!db.active) return
const now=new Date()
const wib=new Date(now.toLocaleString('en-US',{timeZone:'Asia/Jakarta'}))
const jam=wib.getHours().toString().padStart(2,'0')
const menit=wib.getMinutes().toString().padStart(2,'0')
const waktuSekarang=`${jam}:${menit}`
const hariIni=wib.toDateString()
for(const [nama,waktu] of Object.entries(jadwalSholat)){
if(waktuSekarang===waktu && db.lastSent[nama]!==hariIni){
const alipInstance=global.alipInstance
if(!alipInstance) return
const groups=await alipInstance.groupFetchAllParticipating()
const ids=Object.keys(groups)
for(const id of ids){
await alipInstance.sendMessage(id,{
audio:{url:'https://cdn.yupra.my.id/yp/isu1q6dq.mp3'},
mimetype:'audio/mpeg',
ptt:false,
contextInfo:{
externalAdReply:{
title:`🔔 Waktunya Sholat ${nama}`,
body:`Wilayah Jakarta dan sekitarnya`,
thumbnailUrl:'https://cdn.yupra.my.id/yp/njdmvhdc.jpg',
sourceUrl:'https://www.google.com/search?q=waktu+sholat+jakarta',
mediaType:1,
renderLargerThumbnail:true
}
}
}).catch(()=>{})
await new Promise(r=>setTimeout(r,2000))
}
db.lastSent[nama]=hariIni
saveDB(db)
}
}
}catch(e){}
},60000)
global.sholatCheckerStarted=true
}

let handler=async(m,{alip,command,isCreator,Reply,text})=>{
global.alipInstance=alip
const db=loadDB()

if(command==="autosholat"){
if(!isCreator) return Reply("❌ Khusus owner!")

if(text === "on"){
db.active=true
saveDB(db)
return Reply("✅ Pengingat sholat diaktifkan")
}

if(text === "off"){
db.active=false
saveDB(db)
return Reply("❌ Pengingat sholat dimatikan")
}

let jadwal="🕋 *JADWAL SHOLAT*\n\n"
for(const [s,w] of Object.entries(jadwalSholat)){
jadwal+=`• ${s} : ${w}\n`
}

Reply(`📊 *STATUS PENGINGAT SHOLAT*

Status: ${db.active?'🟢 Aktif':'🔴 Nonaktif'}

${jadwal}

Gunakan:
.autosholat on
.autosholat off`)
}

else if(command==="autosholaton"){
if(!isCreator) return Reply("❌ Khusus owner!")
db.active=true
saveDB(db)
Reply("✅ Pengingat sholat diaktifkan")
}

else if(command==="autosholatoff"){
if(!isCreator) return Reply("❌ Khusus owner!")
db.active=false
saveDB(db)
Reply("❌ Pengingat sholat dimatikan")
}

else if(command==="testsholat"){
if(!isCreator) return Reply("❌ Khusus owner!")
const groups=await alip.groupFetchAllParticipating()
const ids=Object.keys(groups)
for(const id of ids){
await alip.sendMessage(id,{
audio:{url:'https://cdn.yupra.my.id/yp/isu1q6dq.mp3'},
mimetype:'audio/mpeg',
ptt:false
})
}
Reply("✅ Test pengingat sholat dikirim")
}
}

handler.command=[
"autosholat",
"testsholat"
]

module.exports=handler