/*
 * Plugin: Panel Management System
 * Author: ALIP-AI
 * Since: 2024 - 2026
 */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const fetch = require("node-fetch");

const DB_DIR = path.join(process.cwd(), "library/database");
const DB_USERS = path.join(DB_DIR, "panel_users.json");
const DB_PANELS = path.join(DB_DIR, "panel_panels.json");

function ensureDB() {
  if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
  if (!fs.existsSync(DB_USERS)) fs.writeFileSync(DB_USERS, "[]", "utf8");
  if (!fs.existsSync(DB_PANELS)) fs.writeFileSync(DB_PANELS, "[]", "utf8");
}

function readJSON(file) {
  ensureDB();
  try {
    const raw = fs.readFileSync(file, "utf8");
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function writeJSON(file, data) {
  ensureDB();
  fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
}

const fallbackPrefix =
  global.prefix && typeof global.prefix === "string" ? global.prefix : ".";

function normalizePhone(n) {
  n = String(n || "").replace(/\D/g, "");
  if (n.startsWith("0")) n = "62" + n.slice(1);
  if (!n.startsWith("62")) n = "62" + n;
  return n;
}

function toServerName(username) {
  let up = String(username || "").toUpperCase().trim();
  if (up.endsWith("STORE") && !up.includes(" ")) up = up.replace(/STORE$/, " STORE");
  return up;
}

function loadPanelDB() {
  return readJSON(DB_PANELS);
}
function savePanelDB(db) {
  writeJSON(DB_PANELS, db);
}
function upsertPanel(serverId, entry) {
  const db = loadPanelDB();
  const idx = db.findIndex((x) => String(x.serverId) === String(serverId));

  if (idx >= 0) db[idx] = { ...db[idx], ...entry };
  else db.push(entry);

  savePanelDB(db);
}
function getPanelByServerId(serverId) {
  const db = loadPanelDB();
  return db.find((p) => String(p.serverId) === String(serverId));
}
function removePanelEntry(serverId) {
  const db = loadPanelDB();
  const filtered = db.filter((p) => String(p.serverId) !== String(serverId));
  savePanelDB(filtered);
  return filtered.length !== db.length;
}

const isResellerFn =
  typeof global.isReseller === "function" ? global.isReseller : () => false;

async function suspendServer(serverId) {
  try {
    await fetch(`${global.domain}/api/application/servers/${serverId}/suspend`, {
      method: "POST",
      headers: { Authorization: `Bearer ${global.apikey}`, Accept: "application/json" },
    });
    return true;
  } catch {
    return false;
  }
}

async function unsuspendServer(serverId) {
  try {
    await fetch(`${global.domain}/api/application/servers/${serverId}/unsuspend`, {
      method: "POST",
      headers: { Authorization: `Bearer ${global.apikey}`, Accept: "application/json" },
    });
    return true;
  } catch {
    return false;
  }
}

function canManage(panel, isCreator, isReseller, sender) {
  if (isCreator) return true;
  if (!isReseller) return false;
  return panel && panel.reseller === sender;
}

function buildCopyButtons(username, password) {
  return [
    {
      buttonId: "copy_username",
      buttonText: { displayText: "📋 Copy Username" },
      type: 4,
      nativeFlowInfo: {
        name: "cta_copy",
        paramsJson: JSON.stringify({
          display_text: "Copy Username",
          copy_code: String(username),
        }),
      },
    },
    {
      buttonId: "copy_password",
      buttonText: { displayText: "🔑 Copy Password" },
      type: 4,
      nativeFlowInfo: {
        name: "cta_copy",
        paramsJson: JSON.stringify({
          display_text: "Copy Password",
          copy_code: String(password),
        }),
      },
    },
  ];
}

let handler = async (m, { alip, command, text, isCreator, Reply }) => {
  ensureDB();

  const domain = global.domain;
  const apikey = global.apikey;
  const nestid = global.nestid;
  const egg = global.egg;
  const loc = global.loc;

  if (!domain || !apikey || !nestid || !egg || !loc) {
    return Reply("❌ PANEL SETTING belum lengkap di global.");
  }

  const isReseller = isResellerFn(m.sender);
  const cmd = String(command || "").toLowerCase();
  const input = String(text || "").trim();

  const createCommands = ["2gb", "3gb", "4gb", "5gb", "7gb", "10gb", "15", "20gb", "25gb", "unlimited", "unli"];
  const specs = {
        "2gb": { ram: "2048", disk: "3048", cpu: "100" },
        "3gb": { ram: "3096", disk: "4096", cpu: "140" },
        "4gb": { ram: "4096", disk: "5096", cpu: "160" },
        "5gb": { ram: "5096", disk: "6096", cpu: "180" },
        "7gb": { ram: "7096", disk: "8096", cpu: "220" },
        "10gb": { ram: "10096", disk: "13000", cpu: "260" },
        "15gb": { ram: "15096", disk: "17000", cpu: "280" },
        "20gb": { ram: "20096", disk: "21000", cpu: "300" },
        "25gb": { ram: "25096", disk: "23000", cpu: "400" },
        "unlimited": { ram: "0", disk: "0", cpu: "0" },
        "unli": { ram: "0", disk: "0", cpu: "0" }
    };

  if (createCommands.includes(cmd)) {
    if (!isCreator && !isReseller) {
      return Reply(
        "AKSES DITOLAK! Fitur ini hanya untuk Reseller atau Owner. Hubungi owner jika ingin menjadi reseller."
      );
    }

    if (!input || !input.includes("|")) {
      return Reply(`Contoh:\n${fallbackPrefix}${cmd} username|628xxx|30`);
    }

    let [usernameRaw, nomorRaw, hariRaw] = input.split("|").map((v) => (v || "").trim());

    const username = String(usernameRaw || "").toLowerCase();
    const phone = normalizePhone(nomorRaw);
    const days = parseInt(hariRaw, 10);

    if (isNaN(days) || days <= 0 || days > 365) return Reply("Jumlah hari tidak valid. Harap masukkan angka 1-365.");
    if (!/^[a-z0-9]{3,15}$/.test(username)) return Reply("Username tidak valid. Hanya huruf kecil & angka (3-15).");
    if (!phone || phone.length < 10) return Reply("Nomor user tidak valid.");

    const spec = specs[cmd];
    const ram = spec.ram;
    const disknya = spec.disk;
    const cpu = spec.cpu;

    try {
      await m.reply("⏳ Membuat panel... Mohon tunggu.");

      const usersDB = readJSON(DB_USERS);
      let userEntry = usersDB.find((u) => String(u.phone) === String(phone));

      let panelUser;
      let password;

      if (!userEntry) {
        const email = `${username}@gmail.com`;
        const first_name = toServerName(username);
        password = username + crypto.randomBytes(2).toString("hex");

        const checkUser = await fetch(
          `${domain}/api/application/users?filter[username]=${encodeURIComponent(username)}`,
          { method: "GET", headers: { Authorization: `Bearer ${apikey}`, Accept: "application/json" } }
        );
        const checkData = await checkUser.json();

        if (checkData?.data?.length > 0) {
          const u = checkData.data[0].attributes;
          return Reply(`Username ${u.username} sudah terdaftar (email ${u.email}). Gunakan username lain.`);
        }

        const f = await fetch(domain + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + apikey,
          },
          body: JSON.stringify({
            email,
            username,
            first_name,
            last_name: "USER",
            language: "en",
            password,
          }),
        });

        const data = await f.json();
        if (data?.errors) return Reply(`Gagal membuat user.\nDetail: ${JSON.stringify(data.errors[0], null, 2)}`);

        panelUser = data.attributes;

        userEntry = {
          phone,
          userId: panelUser.id,
          username: panelUser.username,
          email: panelUser.email,
          password,
          createdAt: Date.now(),
        };
        usersDB.push(userEntry);
        writeJSON(DB_USERS, usersDB);
      } else {
        panelUser = { id: userEntry.userId, username: userEntry.username, email: userEntry.email };
        password = userEntry.password;
      }

      const f1 = await fetch(`${domain}/api/application/nests/${nestid}/eggs/${egg}`, {
        method: "GET",
        headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: "Bearer " + apikey },
      });
      const data2 = await f1.json();
      if (data2?.errors) return Reply(`Gagal ambil egg.\nDetail: ${JSON.stringify(data2.errors[0], null, 2)}`);

      const startup_cmd = data2.attributes.startup;
      const serverName = toServerName(username);

      const f2 = await fetch(domain + "/api/application/servers", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: "Bearer " + apikey,
        },
        body: JSON.stringify({
          name: serverName,
          description: `Server dibuat pada ${new Date().toLocaleDateString("id-ID")}`,
          user: panelUser.id,
          egg: parseInt(egg),
          docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
          startup: startup_cmd,
          environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
          limits: { memory: ram, swap: 0, disk: disknya, io: 500, cpu: cpu },
          feature_limits: { databases: 5, backups: 5, allocations: 5 },
          deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] },
        }),
      });

      const result = await f2.json();
      if (result?.errors) return Reply(`Gagal membuat server.\nDetail: ${JSON.stringify(result.errors[0], null, 2)}`);

      const server = result.attributes;
      const expiresAt = Date.now() + days * 24 * 60 * 60 * 1000;

      upsertPanel(server.id, {
        serverId: server.id,
        name: server.name,
        owner: phone,
        username: panelUser.username,
        email: panelUser.email,
        reseller: isReseller ? m.sender : null,
        expiresAt,
        suspended: false,
        created: Date.now(),
        lastRenewed: Date.now(),
        notified: false,
        spec: { ram, disk: disknya, cpu, type: cmd },
      });

      const expiryDate = new Date(expiresAt).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

      const teks =
`╭─⬣「 *PANEL DIBUAT* 」⬣
│
├─ *Detail Akun (Login Tetap)*
│  ├─ 👤 Username: \`${panelUser.username}\`
│  ├─ 🔑 Password: \`${password}\`
│  └─ 🌐 Login: ${global.domain}
│
├─ *Spesifikasi*
│  ├─ 💾 RAM: ${ram == "0" ? "Unlimited" : ram / 1000 + "GB"}
│  ├─ 💽 Disk: ${disknya == "0" ? "Unlimited" : disknya / 1000 + "GB"}
│  └─ ⚡ CPU: ${cpu == "0" ? "Unlimited" : cpu + "%"}
│
├─ *Informasi Server*
│  ├─ 🏷️ Nama: ${server.name}
│  ├─ 🆔 Server ID: ${server.id}
│  ├─ ⏰ Durasi: ${days} Hari
│  └─ 📅 Expired: ${expiryDate}
│
╰─⬣

✨ *Garansi 29 Hari*
*(1 BULAN DIHITUNG 29-30 HARI)*
⚠️ *Aturan:*
- *Dilarang keras* menyebarkan atau memperlihatkan link panel dengan alasan apapun!
- Jika ingin screenshot, *WAJIB sensor* link panel.
- *Jaga baik-baik data panel kamu!* Karena jika bocor, botmu bisa berakibat fatal.
- *Garansi hanya berlaku jika kamu mematuhi syarat & ketentuan.*
- *Dilarang gunakan untuk hal ilegal!*
`;

      const targetJid = `${phone}@s.whatsapp.net`;

      if (m.isGroup) await Reply("✅ Panel berhasil dibuat! Data login dikirim ke nomor yang terdaftar.");

      const msgToTarget = {
        text: teks,
        footer: "mantap",
        buttons: buildCopyButtons(panelUser.username, password),
        headerType: 1,
        viewOnce: true,
      };

      try {
        await alip.sendMessage(targetJid, msgToTarget, { quoted: m });
      } catch (e) {
        console.error("Send Login To Target Error:", e);
        await Reply(
          `⚠️ Panel berhasil dibuat, tapi *gagal kirim data login ke nomor target* (${phone}).\n` +
          `Pastikan nomor aktif WhatsApp & bisa menerima chat.`
        );
      }

      return;
    } catch (err) {
      console.error("Panel Creation Error:", err);
      return Reply(`❌ Terjadi error saat membuat panel.\n${err?.message || err}`);
    }
  }

  if (cmd === "mypanel") {
    try {
      const phone = normalizePhone(m.sender.split("@")[0]);
      const usersDB = readJSON(DB_USERS);
      const panelDB = loadPanelDB();

      const user = usersDB.find((u) => u.phone === phone);
      const myServers = panelDB.filter((p) => String(p.owner || "").startsWith(phone));

      if (!user || myServers.length === 0) return Reply("❌ Kamu belum punya server panel.");

      for (const p of myServers) {
        const daysLeft = Math.ceil((p.expiresAt - Date.now()) / (1000 * 60 * 60 * 24));
        if (daysLeft <= 0 && !p.suspended) {
          try {
            await suspendServer(p.serverId);
            p.suspended = true;
          } catch {}
        }
      }
      savePanelDB(panelDB);

      let teks = `╭─⬣「 *PANEL KAMU* 」⬣\n│\n`;
      teks += `├─ 👤 User: *${user.username}*\n`;
      teks += `├─ 📱 Nomor: *${phone}*\n`;
      teks += `├─ 🖥️ Total Server: *${myServers.length}*\n│\n`;
      teks += `├─ *Daftar Server:*\n`;

      let i = 0;
      for (const p of myServers) {
        const daysLeft = Math.ceil((p.expiresAt - Date.now()) / (1000 * 60 * 60 * 24));
        const status = daysLeft > 0 ? `🟢 ${daysLeft}d` : `🔴 EXPIRED${p.suspended ? " / SUSPEND" : ""}`;
        const expDate = new Date(p.expiresAt).toLocaleDateString("id-ID");
        teks += `│  ${++i}. ${p.name || p.serverName || "SERVER"} — ${status} (Exp: ${expDate})\n`;
      }

      teks += `│\n╰─⬣\n\n🔒 *Data login tidak ditampilkan demi keamanan.*`;
      return Reply(teks);
    } catch (e) {
      console.error("MyPanel Error:", e);
      return Reply("❌ Gagal mengambil data panel kamu.");
    }
  }

  if (cmd === "listpanel") {
    if (!isCreator && !isReseller) {
      return Reply("⛔ *AKSES DITOLAK!\n\nFitur ini hanya untuk *Owner dan Reseller*!");
    }

    try {
      await m.reply("⏳ *Mengambil daftar panel dari server...*");

      const res = await fetch(`${domain}/api/application/servers`, {
        method: "GET",
        headers: { Authorization: `Bearer ${apikey}`, Accept: "application/json" },
      });

      if (!res.ok) return Reply(`❌ Gagal mengambil data dari server (${res.status}).`);

      const data = await res.json();
      if (!data.data || data.data.length === 0) return Reply("⚠️ Tidak ada server yang aktif di panel.");

      const allPanels = loadPanelDB();

      const filtered =
        !isCreator && isReseller
          ? data.data.filter((s) => {
              const p = allPanels.find((x) => String(x.serverId) === String(s.attributes.id));
              return p && p.reseller === m.sender;
            })
          : data.data;

      if (filtered.length === 0) return Reply("❌ Tidak ada server yang terdaftar untuk akun kamu.");

      let listText = "╭─⬣「 *DAFTAR SERVER PANEL* 」⬣\n│\n";
      let serverCount = 0;
      let activeInDB = 0;
      let expiredInDB = 0;

      for (const server of filtered) {
        const serverId = server.attributes.id;
        const serverName = server.attributes.name;
        const serverUser = server.attributes.user;

        const panelInfo = allPanels.find((p) => String(p.serverId) === String(serverId));
        const daysLeft = panelInfo
          ? Math.ceil((panelInfo.expiresAt - Date.now()) / (1000 * 60 * 60 * 24))
          : 0;

        const status = panelInfo ? (daysLeft > 0 ? "🟢" : "🔴") : "⚪";

        listText += `├─ ${++serverCount}. ${serverName}\n`;
        listText += `│  ├─ 🆔 ID: ${serverId}\n`;
        listText += `│  ├─ 👤 User: ${serverUser}\n`;

        if (panelInfo) {
          listText += `│  ├─ 👤 Owner: ${panelInfo.owner}\n`;
          listText += `│  ├─ 📅 Expiry: ${new Date(panelInfo.expiresAt).toLocaleDateString("id-ID")}\n`;
          listText += `│  └─ 🔋 Status: ${status} (${daysLeft}d)\n`;
          if (daysLeft > 0) activeInDB++;
          else expiredInDB++;
        } else {
          listText += `│  └─ ⚠️ Tidak ada di database\n`;
        }
      }

      const notInServer = allPanels.filter(
        (p) => !data.data.some((s) => String(s.attributes.id) === String(p.serverId))
      ).length;

      listText += `│\n├─ *Statistik*\n`;
      listText += `│  ├─ 🖥️ Server Ditampilkan: ${serverCount}\n`;
      listText += `│  ├─ ✅ Aktif di DB: ${activeInDB}\n`;
      listText += `│  ├─ 🔴 Expired di DB: ${expiredInDB}\n`;
      listText += `│  └─ 🗑️ Tidak di Server: ${notInServer}\n`;
      listText += "╰─⬣";

      return Reply(listText);
    } catch (e) {
      console.error("ListPanel Error:", e);
      return Reply("❌ Gagal mengambil data dari server panel.");
    }
  }

  if (cmd === "renew" || cmd === "renewserver") {
    if (!isCreator && !isReseller) {
      return Reply("⛔ AKSES DITOLAK!\n\nFitur ini hanya untuk Reseller atau Owner.");
    }

    try {
      if (!input) {
        const res = await fetch(`${domain}/api/application/servers`, {
          method: "GET",
          headers: { Authorization: `Bearer ${apikey}`, Accept: "application/json" },
        });

        if (!res.ok) return Reply("❌ Gagal mengambil data server.");

        const data = await res.json();
        const allPanels = loadPanelDB();

        const myServers = data.data.filter((server) => {
          if (isCreator) return true;
          const panel = allPanels.find((p) => String(p.serverId) === String(server.attributes.id));
          return panel && panel.reseller === m.sender;
        });

        if (myServers.length === 0) return Reply("❌ Tidak ada server yang bisa di-renew.");

        let message = `🔄 *DAFTAR SERVER YANG BISA DI-RENEW*\n\n`;
        let serverCount = 0;

        for (const server of myServers) {
          const serverId = server.attributes.id;
          const serverName = server.attributes.name;
          const panel = allPanels.find((p) => String(p.serverId) === String(serverId));
          const daysLeft = panel ? Math.ceil((panel.expiresAt - Date.now()) / (1000 * 60 * 60 * 24)) : 0;
          const status = panel ? (daysLeft > 0 ? `🟢 (${daysLeft}d)` : `🔴 (EXPIRED)`) : `⚪ (Belum ada expiry)`;

          message += `*${++serverCount}. ${serverName}*\n`;
          message += `   🆔 Server ID: ${serverId}\n`;
          message += `   ⏰ Status: ${status}\n`;
          message += `   🔄 Renew: *${fallbackPrefix}renew ${serverId}*\n\n`;
        }

        message += `_Gunakan command di atas untuk renew server._`;
        return Reply(message);
      }

      const serverId = Number(input);
      if (!Number.isFinite(serverId) || serverId <= 0) return Reply("❌ Server ID harus angka yang valid.");

      const verifyRes = await fetch(`${domain}/api/application/servers/${serverId}`, {
        method: "GET",
        headers: { Authorization: `Bearer ${apikey}`, Accept: "application/json" },
      });

      if (!verifyRes.ok) {
        if (verifyRes.status === 404) {
          removePanelEntry(serverId);
          return Reply(`❌ Server ID *${serverId}* tidak ditemukan di panel. Entri database dibersihkan.`);
        }
        return Reply(`❌ Gagal memverifikasi server: ${verifyRes.status}`);
      }

      const serverData = await verifyRes.json();
      const server = serverData.attributes;

      const db = loadPanelDB();
      const panel = db.find((p) => String(p.serverId) === String(serverId));

      if (!canManage(panel, isCreator, isReseller, m.sender)) {
        return Reply(`❌ Server *${server.name}* bukan milik Anda.`);
      }

      const daysAdd = 30;
      const now = Date.now();

      let newExpiry;
      if (panel && panel.expiresAt && Number(panel.expiresAt) > now) {
        newExpiry = Number(panel.expiresAt) + daysAdd * 24 * 60 * 60 * 1000;
      } else {
        newExpiry = now + daysAdd * 24 * 60 * 60 * 1000;
      }

      upsertPanel(serverId, {
        serverId,
        name: panel?.name || server.name,
        serverName: server.name,
        expiresAt: newExpiry,
        lastRenewed: now,
        suspended: false,
        notified: false,
      });

      await unsuspendServer(serverId).catch(() => {});

      const oldExp = panel?.expiresAt ? new Date(panel.expiresAt) : new Date(now);
      const newExp = new Date(newExpiry);

      const successText =
`✅ *RENEW SERVER BERHASIL!*

🏷️ *Nama:* ${server.name}
🆔 *Server ID:* ${serverId}
👤 *User:* ${server.user}
➕ *Ditambah:* ${daysAdd} hari
📅 *Expiry Lama:* ${oldExp.toLocaleDateString("id-ID")}
📅 *Expiry Baru:* ${newExp.toLocaleDateString("id-ID")}

✅ Server berhasil diperpanjang!`;

      return Reply(successText);
    } catch (error) {
      console.error("Renew Error:", error);
      return Reply(`❌ Terjadi kesalahan saat renew: ${error?.message || error}`);
    }
  }

  if (cmd === "deletepanel" || cmd === "delpanel") {
    if (!isCreator && !isReseller) {
      return Reply("⛔ AKSES DITOLAK!\n\nFitur ini hanya untuk Reseller atau Owner.");
    }

    if (!input) return Reply(`❌ Format salah.\nGunakan: *${fallbackPrefix}delpanel <server id>*`);

    try {
      const serverIdNum = parseInt(input, 10);
      if (isNaN(serverIdNum) || serverIdNum <= 0) return Reply("❌ Server ID harus berupa angka yang valid.");

      const panel = getPanelByServerId(serverIdNum);
      if (!panel) return Reply(`❌ Server ID *${serverIdNum}* tidak ditemukan di database lokal.`);

      if (!canManage(panel, isCreator, isReseller, m.sender)) {
        return Reply(`❌ Server *${panel.username || panel.name || panel.serverId}* bukan milik Anda dan tidak bisa dihapus.`);
      }

      let apiStatus = "GAGAL";
      let apiDetail = "";

      try {
        const delRes = await fetch(`${domain}/api/application/servers/${serverIdNum}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${apikey}`, Accept: "application/json" },
        });

        if (delRes.status === 204) {
          apiStatus = "BERHASIL";
        } else if (delRes.status === 404) {
          apiStatus = "BERHASIL";
          apiDetail = "Server tidak ditemukan di panel (anggap sudah terhapus).";
        } else {
          apiDetail = `Status ${delRes.status}`;
        }
      } catch (e) {
        apiDetail = `Kesalahan koneksi: ${e?.message || e}`;
      }

      removePanelEntry(serverIdNum);

      const successText =
`✅ *PENGHAPUSAN SERVER SELESAI!*

🗑️ *Server ID:* ${serverIdNum}
👤 *Username:* ${panel.username || "N/A"}
📛 *Nama:* ${panel.name || panel.serverName || "N/A"}

*Catatan:*
- Entri database lokal sudah dihapus ✅
- Status penghapusan Pterodactyl: *${apiStatus}*
${apiDetail ? `- Detail API: ${apiDetail}` : ""}

Server ini tidak akan muncul lagi di daftar & tidak akan dicek sistem expired.`;

      return Reply(successText);
    } catch (error) {
      console.error("Delete Panel Error:", error);
      return Reply(`❌ Terjadi kesalahan saat menghapus panel: ${error?.message || error}`);
    }
  }
};

handler.command = [
  "10gb",
  "2gb",
  "3gb",
  "4gb",
  "5gb",
  "15gb",
  "7gb",
  "20",
  "25",
  "unlimited",
  "unli",
  "mypanel",
  "listpanel",
  "renew",
  "renewserver",
  "delpanel",
  "deletepanel",
];

module.exports = handler;