// © ALIP-AI | WhatsApp: 0812-4970-3469
// ⚠️ Do not remove this credit

const { MessagesUpsertt } = require('./source/message.js');
const fs = require('fs');
const chalk = require('chalk');
const { proto, areJidsSameUser, makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, generateForwardMessageContent, prepareWAMessageMedia, generateWAMessageFromContent, generateMessageID, logss, downloadContentFromMessage, Browsers, makeInMemoryStore, sendBites, jidDecode, makeCacheableSignalKeyStore, getAggregateVotesInPollMessage, delay, fetchLatestWaWebVersion } = require("@whiskeysockets/baileys")
const { createCanvas, loadImage, registerFont } = require('canvas');

async function initializHandler(alip, store) {
    async function getProfilePicture(jid) {
        try {
            const url = await alip.profilePictureUrl(jid, 'image');
            if (url && !url.includes('undefined') && !url.includes('null')) {
                return url;
            }
        } catch {}
        return 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg';
    }

    alip.ev.on('messages.upsert', async (message) => {
        await MessagesUpsertt(alip, message, store);
    });

    alip.ev.on('group-participants.update', async (update) => {
    try {
        const { id, participants, action } = update;
        const groupData = global.db.groups[id];
        if (!groupData) return;
        const welcomeFile = './library/database/welcome.json';
        const leftFile = './library/database/left.json';
        const metadata = await alip.safeGroupMetadata(id);
        if (!metadata || !metadata.subject) return;
        const groupName = metadata.subject;
        
  /////////////// INI CANVAS WOK \\\\\\\\\\\\\\\\
        const createGreetingCanvas = async (ppUrl, userTag, groupName, type) => {
        const rahmad = 1000;
        const elaina = 562;
        const lena = createCanvas(rahmad, elaina);
        const ctx = lena.getContext('2d');

    try {
        const bgNyaBang = 'http://elainaacdn.vercel.app/file/c1f4a03647.jpg';
        const bgNya = await loadImage(bgNyaBang);
        ctx.drawImage(bgNya, 0, 0, rahmad, elaina);
    } catch (e) {
        ctx.fillStyle = '#ffc0cb'; 
        ctx.fillRect(0, 0, rahmad, elaina);
    }
        const ppX = 247;
        const ppY = 178; 
        const ppRadius = 155;
        ctx.save();
        ctx.beginPath();
        ctx.arc(ppX, ppY, ppRadius, 0, Math.PI * 2, true);
        ctx.closePath();
        ctx.clip();
    try {
        const pp = await loadImage(ppUrl);
        ctx.drawImage(pp, ppX - ppRadius, ppY - ppRadius, ppRadius * 2, ppRadius * 2);
    } catch {
        const PpNya = await loadImage('https://telegra.ph/file/a059a6a734ed202c879d3.jpg');
        ctx.drawImage(PpNya, ppX - ppRadius, ppY - ppRadius, ppRadius * 2, ppRadius * 2);
    }
    ctx.restore();
    ctx.textAlign = 'center';
    ctx.fillStyle = '#FFFFFF';
    ctx.shadowColor = "rgba(0,0,0,0.8)";
    ctx.shadowBlur = 6;
    ctx.shadowOffsetX = 3;
    ctx.shadowOffsetY = 3;
    ctx.font = 'bold 60px sans-serif';
    const titleText = type === 'add' ? 'WELCOME' : 'GOODBYE';
    ctx.fillText(titleText, 700, 110); 
    ctx.font = 'bold 35px sans-serif';
    let displayGroupName = groupName;
    if (groupName.length > 45) {
        displayGroupName = groupName.substring(0, 42) + "...";}
    ctx.fillText(displayGroupName, 465, 495); 
    return lena.toBuffer();
};

        /////////// WELCOME NYA WOK \\\\\\\\\\
        if (groupData.welcome && action === 'add') {
            const welcomeDB = fs.existsSync(welcomeFile) ? JSON.parse(fs.readFileSync(welcomeFile)) : {};
            for (let n of participants) {
       const groupMetadata = await alip.groupMetadata(id);
       const currentParticipants = groupMetadata.participants;
       const userNum = `@${n.split("@")[0]}`;
       const ppUrl = await alip.profilePictureUrl(n, 'image').catch(() => 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg');   
       const canvasBuffer = await createGreetingCanvas(ppUrl, userNum, groupName, 'add');
       const teksWelcome = welcomeDB[id]?.welcomeText || `*yah si* @user *join bete gua jing*`;
       const teks = teksWelcome.replace(/@user/g, userNum).replace(/@group/g, groupName);
       
       //////// INI DEFAULT INTRO NYA \\\\\\\\
                let introTemplate = global.db.groups[id]?.intro?.template || 
                `╔──☉ INTRO MEMBER\n│ ✦ Nama: •••\n│ ✦ Umur: •••\n│ ✦ Gender: •••\n│ ✦ Askot: •••\n╚────────────☉`;
       const msg = generateWAMessageFromContent(id, {
                   viewOnceMessage: {
                   message: {
                   interactiveMessage: proto.Message.InteractiveMessage.create({
                   body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                   footer: proto.Message.InteractiveMessage.Footer.create({ text: `*Total Anggota:* ${currentParticipants.length} *orang*` }),
                   header: proto.Message.InteractiveMessage.Header.create({
                   hasMediaAttachment: true,
                   imageMessage: (await prepareWAMessageMedia({ image: canvasBuffer }, { upload: alip.waUploadToServer })).imageMessage
                                }),
                   nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                   buttons: [{
                              name: "cta_copy",
                              buttonParamsJson: JSON.stringify({ display_text: "copy intro", copy_code: introTemplate })
                             }]
                             }),
                   contextInfo: {
                   mentionedJid: [n],
                   externalAdReply: {
                   containsAutoReply: true,
                   thumbnailUrl: ppUrl,
                   title: 'Selamat Datang Di Grup',
                   body: groupName,                 
                   sourceUrl: global.linkSaluran,
                   mediaType: 1}}})
                   }}}, { quoted: { key: { remoteJid: id, fromMe: false, participant: n }, message: { conversation: 'hai salam kenal 👋' }}});
       await alip.relayMessage(id, msg.message, { messageId: msg.key.id });
            }
        /////// LEFT NYA CIK \\\\\\
        } else if (groupData.left && action === 'remove') {
            const leftDB = fs.existsSync(leftFile) ? JSON.parse(fs.readFileSync(leftFile)) : {};
            for (let n of participants) {
                const groupMetadata = await alip.groupMetadata(id);
                const currentParticipants = groupMetadata.participants;
                const userNum = `@${n.split("@")[0]}`;
                const ppUrl = await alip.profilePictureUrl(n, 'image').catch(() => 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg');
                const canvasBuffer = await createGreetingCanvas(ppUrl, userNum, groupName, 'remove');
                const teksLeft = leftDB[id]?.leftText || `*Goodbye* @user 👋`;
                const teks = teksLeft.replace(/@user/g, userNum).replace(/@group/g, groupName);
                const pesanWasiat = `iya gua tau muka gua kek peler`;
                const msg = generateWAMessageFromContent(id, {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                                footer: proto.Message.InteractiveMessage.Footer.create({ text: `*Total Anggota:* ${currentParticipants.length} *orang*` }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    hasMediaAttachment: true,
                                    imageMessage: (await prepareWAMessageMedia({ image: canvasBuffer }, { upload: alip.waUploadToServer })).imageMessage
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [{
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({ display_text: "copy pesan wasiat", copy_code: pesanWasiat })
                                    }]
                                }),
                                contextInfo: {
                                    mentionedJid: [n],
                                    externalAdReply: {
                                        containsAutoReply: true,
                                        thumbnailUrl: ppUrl,
                                        title: 'Bro Tereliminasi Dari Grup',
                                        body: groupName,
                                        renderLargerThumbnail: false,
                                        sourceUrl: global.linkSaluran,
                                        mediaType: 1
                                    }
                                }
                            })
                        }
                    }
                }, { quoted: { key: { remoteJid: id, fromMe: false, participant: n }, message: { conversation: 'malas' } } });
                await alip.relayMessage(id, msg.message, { messageId: msg.key.id });
            }
        }
    } catch (err) { 
        console.log('❌ Error di handler.js', err);
    }
});
  // INI UNTUK NOTIFIKASI PROMOTE DAN DEMOTE ADMIN CIK \\
   alip.ev.on('group-participants.update', async (rahmad) => {
   try {
     let metadata = await alip.groupMetadata(rahmad.id);
     const participants = rahmad.participants;
     const pelaku = rahmad.author;
     metadata = await alip.groupMetadata(rahmad.id);
     const currentAdmins = metadata.participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin' || p.admin === true);
     const jumlahAdmin = currentAdmins.length;
     if (rahmad.action !== 'promote' && rahmad.action !== 'demote') return;
     const emotnya = rahmad.action === 'promote' ? '👑' : '👤';
     const titelnya = rahmad.action === 'promote' ? 'PROMOSI ADMIN' : 'ADMIN DIPECAT';
     const katanya = rahmad.action === 'promote' ? 'sekarang menjadi *Admin Grup*' : 'bukan lagi *Admin Grup*';
     const fakenya = rahmad.action === 'promote' ? 'adminin gua cik😂' : 'atmin hanyalah alat😂';
     const tersangka = participants.map(jid => `@${jid.split('@')[0]}`).join(', ');
     const teks = `${emotnya} *${titelnya}*\n\n` +
                 `User: ${tersangka}\n` +
                 `${katanya}\n` +
                 `Oleh: @${pelaku.split('@')[0]}`;

     await alip.sendMessage(rahmad.id, {
      text: teks,
      mentions: [...participants, pelaku],
      footer: `*Total Admin :* ${jumlahAdmin} admin`,
      buttons: [
        { buttonId: 'ok', buttonText: { displayText: 'terima kasih'}, type: 1 }
               ],
      contextInfo: {
      mentionedJid: [...participants, pelaku],
      externalAdReply: {
      title: rahmad.action === 'promote' ? 'telah menjadi admin grup' : 'admin dicopot',
      body: metadata.subject || 'Grup Ini',
      thumbnailUrl: await getProfilePicture(participants[0]) || ''}}},
      {quoted: {
      key: {
      participant: participants[0],
      remoteJid: rahmad.id,
      fromMe: false,
      id: ''},
      message: {
      conversation: fakenya}}});
  } catch (err) {
    console.error(err);
  }
});
    
    alip.ev.on("groups.update", (updates) => {
        for (const update of updates) {
            const id = update.id;
            if (store.groupMetadata[id]) {
                store.groupMetadata[id] = { ...(store.groupMetadata[id] || {}), ...(update || {}) };
            }
        }
    });
}

module.exports = { initializHandler };

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
});