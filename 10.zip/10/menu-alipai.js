// © ALIP-AI | WhatsApp: 0812-4970-3469
// ⚠️ Do not remove this credit

require('./settings');
require('./alipai-cmd');
const fs = require('fs');
const chalk = require('chalk');

global.menuowner = `
╭➤--「OWNER MENU 」
┆ ⇝ .addaksesprem
┆ ⇝ .addcase
┆ ⇝ .addgold
┆ ⇝ .addlimit
┆ ⇝ .addlimitall
┆ ⇝ .addowner
┆ ⇝ .addprem
┆ ⇝ .addsewagc
┆ ⇝ .addsticker
┆ ⇝ .antispam
┆ ⇝ .antibot
┆ ⇝ .autobackup
┆ ⇝ .autoread
┆ ⇝ .autosholat
┆ ⇝ .autotyping
┆ ⇝ .backup
┆ ⇝ .banfitur
┆ ⇝ .blacklist
┆ ⇝ .cadp
┆ ⇝ .cekprem
┆ ⇝ .ceksewagc
┆ ⇝ .clearchat
┆ ⇝ .clearprem
┆ ⇝ .creategc
┆ ⇝ .createhtml
┆ ⇝ .delaksesprem
┆ ⇝ .delcase
┆ ⇝ .dellimit
┆ ⇝ .delowner
┆ ⇝ .delprem
┆ ⇝ .delsewagc
┆ ⇝ .delsticker
┆ ⇝ .delstikercmd
┆ ⇝ .delcapjulukan
┆ ⇝ .editcapjulukan
┆ ⇝ .getcase
┆ ⇝ .getfile
┆ ⇝ .getsc
┆ ⇝ .getsticker
┆ ⇝ .joinch
┆ ⇝ .joingc
┆ ⇝ .jpmtag
┆ ⇝ .listaksesprem
┆ ⇝ .listcase
┆ ⇝ .listgc
┆ ⇝ .listowner
┆ ⇝ .listprem
┆ ⇝ .listsewagc
┆ ⇝ .liststicker
┆ ⇝ .onlyprem
┆ ⇝ .outgc
┆ ⇝ .pay2
┆ ⇝ .renewsewagc
┆ ⇝ .renamebot
┆ ⇝ .resetdb
┆ ⇝ .resetdatabase
┆ ⇝ .resetgroupdb
┆ ⇝ .resetlimitall
┆ ⇝ .restartbot
┆ ⇝ .savekontak
┆ ⇝ .saveweb
┆ ⇝ .self/public
┆ ⇝ .sendgc
┆ ⇝ .setaudiomenu
┆ ⇝ .setdaftar
┆ ⇝ .setpanel
┆ ⇝ .setfakereply
┆ ⇝ .setgifmenu
┆ ⇝ .setimgdocument
┆ ⇝ .setlimit
┆ ⇝ .setmenu
┆ ⇝ .setppbot
┆ ⇝ .setpppanjang
┆ ⇝ .setimg
┆ ⇝ .stikercmd
┆ ⇝ .swgcall
┆ ⇝ .unbanfitur
┆ ⇝ .unblacklist
┆ ⇝ .upchannel
┆ ⇝ .upchannel2
┆ ⇝ .addmenu
┆ ⇝ .delmenu
┆ ⇝ .cekfolder
┆ ⇝ .uploadfile
╰➤-------------------------------
`

global.menugroup = `
╭➤--「GROUP MENU 」
┆ ⇝ .acc
┆ ⇝ .afk
┆ ⇝ .antilink
┆ ⇝ .antilinkgc
┆ ⇝ .antilinkch
┆ ⇝ .antilinkall
┆ ⇝ .antilinkcapcut
┆ ⇝ .antilinkyt
┆ ⇝ .antilinkig
┆ ⇝ .antilinktt
┆ ⇝ .antilinkfb
┆ ⇝ .antinsfw
┆ ⇝ .antikontak
┆ ⇝ .antisticker
┆ ⇝ .antifoto
┆ ⇝ .antivideo
┆ ⇝ .antilokasi
┆ ⇝ .antiaudio
┆ ⇝ .antidokumen
┆ ⇝ .antidelete
┆ ⇝ .antitagsw
┆ ⇝ .antibot
┆ ⇝ .antipromosi
┆ ⇝ .antitoxic
┆ ⇝ .autosticker
┆ ⇝ .autodownload
┆ ⇝ .autoabsen
┆ ⇝ .alarm
┆ ⇝ .banfitur
┆ ⇝ .capjulukan
┆ ⇝ .cekidch
┆ ⇝ .cekidgc
┆ ⇝ .close
┆ ⇝ .closetime
┆ ⇝ .delultah
┆ ⇝ .delwarn
┆ ⇝ .dekppgc
┆ ⇝ .demote
┆ ⇝ .fitnah
┆ ⇝ .gcsider
┆ ⇝ .hapusabsen
┆ ⇝ .hidetag
┆ ⇝ .hidetagpoll
┆ ⇝ .infowarn
┆ ⇝ .infouser
┆ ⇝ .intro
┆ ⇝ .kick
┆ ⇝ .kudetagc
┆ ⇝ .leaderboard
┆ ⇝ .leave
┆ ⇝ .linkgc
┆ ⇝ .listultah
┆ ⇝ .listwarn
┆ ⇝ .listcapjulukan
┆ ⇝ .misteribox
┆ ⇝ .onlyadmin
┆ ⇝ .open
┆ ⇝ .opentime
┆ ⇝ .promote
┆ ⇝ .resetlinkgc
┆ ⇝ .resettotalchat
┆ ⇝ .resetwarn
┆ ⇝ .schedule
┆ ⇝ .setabsen
┆ ⇝ .setopen
┆ ⇝ .setclose
┆ ⇝ .setopentime
┆ ⇝ .setclosetime
┆ ⇝ .setgc
┆ ⇝ .setintro
┆ ⇝ .setleft
┆ ⇝ .setnamagc
┆ ⇝ .setppgc
┆ ⇝ .setppgcpanjang
┆ ⇝ .setultah
┆ ⇝ .setwelcome
┆ ⇝ .setdeskgc
┆ ⇝ .sidercek
┆ ⇝ .siderkick
┆ ⇝ .swgc
┆ ⇝ .spamtag
┆ ⇝ .tagadmin
┆ ⇝ .tagall
┆ ⇝ .tagme
┆ ⇝ .tolakacc
┆ ⇝ .totalchat
┆ ⇝ .ultah
┆ ⇝ .unbanfitur
┆ ⇝ .warn
╰➤-------------------------------
`

global.menustore = `
╭➤--「STORE MENU 」
┆ ⇝ .list
┆ ⇝ .setlist
┆ ⇝ .addlist
┆ ⇝ .dellist
┆ ⇝ .clearlist
┆ ⇝ .setpay
┆ ⇝ .delpay
┆ ⇝ .listpay
┆ ⇝ .setdone
┆ ⇝ .setproses
┆ ⇝ .done
┆ ⇝ .proses
┆ ⇝ .testimoni
┆ ⇝ .buyprem
┆ ⇝ .buysewagc
┆ ⇝ .ceksaldoatlantis
┆ ⇝ .atlantictf
┆ ⇝ .done
┆ ⇝ .jpm
┆ ⇝ .jpm2
┆ ⇝ .jpmtesti
┆ ⇝ .payment
┆ ⇝ .proses
┆ ⇝ .pushkontak
┆ ⇝ .pushkontak2
┆ ⇝ .sendtesti
╰➤-------------------------------
`
global.menustk = `
╭➤--「 STK MENU 」
┆ ⇝ .stkbaik
┆ ⇝ .stkcantik
┆ ⇝ .stkganteng
┆ ⇝ .stkhitam
┆ ⇝ .stkmiskin
┆ ⇝ .stkkaya
┆ ⇝ .stkmarah
┆ ⇝ .stksabar
┆ ⇝ .stksakiti
┆ ⇝ .stkkeren
┆ ⇝ .stkmisterius
┆ ⇝ .stksantai
┆ ⇝ .stksombong
┆ ⇝ .stklucu
┆ ⇝ .stkgila
╰➤-------------------------------
`

global.menuanime = `
╭➤--「ANIME MENU 」
┆ ⇝ .akira
┆ ⇝ .akiyama
┆ ⇝ .ana
┆ ⇝ .asuna
┆ ⇝ .ayuzawa
┆ ⇝ .boruto
┆ ⇝ .chiho
┆ ⇝ .chitoge
┆ ⇝ .deidara
┆ ⇝ .doraemon
┆ ⇝ .eba
┆ ⇝ .elaina
┆ ⇝ .emilia
┆ ⇝ .erza
┆ ⇝ .gremory
┆ ⇝ .hestia
┆ ⇝ .hinata
┆ ⇝ .husbu
┆ ⇝ .inori
┆ ⇝ .isuzu
┆ ⇝ .itachi
┆ ⇝ .itori
┆ ⇝ .kaga
┆ ⇝ .kakasih
┆ ⇝ .kanna
┆ ⇝ .kaori
┆ ⇝ .keneki
┆ ⇝ .koturi
┆ ⇝ .kurumi
┆ ⇝ .madara
┆ ⇝ .megumin
┆ ⇝ .mikasa
┆ ⇝ .miku
┆ ⇝ .minato
┆ ⇝ .naruto
┆ ⇝ .nezuko
┆ ⇝ .onepiece
┆ ⇝ .pokemon
┆ ⇝ .rize
┆ ⇝ .ryuko
┆ ⇝ .sagiri
┆ ⇝ .sakura
┆ ⇝ .sasuke
┆ ⇝ .shina
┆ ⇝ .shinka
┆ ⇝ .shinomiya
┆ ⇝ .shizuka
┆ ⇝ .shota
┆ ⇝ .tejina
┆ ⇝ .toukachan
┆ ⇝ .tsunade
┆ ⇝ .umaru
┆ ⇝ .waifu
┆ ⇝ .yotsuba
┆ ⇝ .yuli
┆ ⇝ .yumeko
┆ ⇝ .yuri
┆ ⇝ .zero
╰➤-------------------------------
`
global.menunsfw = `
╭➤--「NSFW MENU 」
┆ ⇝ .bokep
┆ ⇝ .nsfw 🅟
┆ ⇝ .nsfwahegao 🅟
┆ ⇝ .nsfwass 🅟
┆ ⇝ .nsfwbdsm 🅟
┆ ⇝ .nsfwgangbang 🅟
┆ ⇝ .nsfwgay 🅟
┆ ⇝ .nsfwloli 🅟
┆ ⇝ .nsfwneko 🅟
┆ ⇝ .nsfwpussy 🅟
┆ ⇝ .nsfwzettai 🅟
╰➤-------------------------------
`
global.menupanel = `
╭➤--「MENU PANEL 」
┆ ⇝ .2gb
┆ ⇝ .3gb
┆ ⇝ .4gb
┆ ⇝ .5gb
┆ ⇝ .6gb
┆ ⇝ .7gb
┆ ⇝ .10gb
┆ ⇝ .15gb
┆ ⇝ .20gb
┆ ⇝ .unli
┆ ⇝ .installpanel
┆ ⇝ .delpanel
┆ ⇝ .renewserver
┆ ⇝ .addreseller
┆ ⇝ .cekres
┆ ⇝ .delreseller
┆ ⇝ .listpanel
┆ ⇝ .listreseller
╰➤-------------------------------
`
global.menucecan = ` 
╭➤--「CECAN MENU 」
┆ ⇝ .cecanchina
┆ ⇝ .cecanhijaber
┆ ⇝ .cecanindonesia
┆ ⇝ .cecanjapan
┆ ⇝ .cecanjeni
┆ ⇝ .cecanjiso
┆ ⇝ .cecankorea
┆ ⇝ .cecanmalaysia
┆ ⇝ .cecanjustinaxie
┆ ⇝ .cecanrose
┆ ⇝ .cecanryujin
┆ ⇝ .cecanthailand
┆ ⇝ .cecanvietnam
╰➤-------------------------------
`
global.menuislam = ` 
╭➤--「ISLAMI MENU 」
┆ ⇝ .asmaulhusna
┆ ⇝ .audiosurah
┆ ⇝ .ayatkursi
┆ ⇝ .bacaansholat
┆ ⇝ .doa
┆ ⇝ .doaharian
┆ ⇝ .hadits
┆ ⇝ .jadwalsholat
┆ ⇝ .kisahnabi
┆ ⇝ .niatsholat
┆ ⇝ .quotesislami
┆ ⇝ .wirid
╰➤-------------------------------
`
global.menuehpoto = ` 
╭➤--「 EPHOTO MENU 」
┆ ⇝ .1917style
┆ ⇝ .advancedglow
┆ ⇝ .blackpink
┆ ⇝ .blackpinklogo
┆ ⇝ .blackpinkstyle
┆ ⇝ .cartoonstyle
┆ ⇝ .deletingtext
┆ ⇝ .dragonfire
┆ ⇝ .effectclouds
┆ ⇝ .eraser
┆ ⇝ .flag3dtext
┆ ⇝ .flagtext
┆ ⇝ .freecreate
┆ ⇝ .galaxy
┆ ⇝ .galaxystyle
┆ ⇝ .galaxywallpaper
┆ ⇝ .glitchtext
┆ ⇝ .glowingtext
┆ ⇝ .gradienttext
┆ ⇝ .grafitti
┆ ⇝ .horor
┆ ⇝ .incandescent
┆ ⇝ .lighteffects
┆ ⇝ .logomaker
┆ ⇝ .luxurygold
┆ ⇝ .makingneon
┆ ⇝ .multicoloredneon
┆ ⇝ .neonglitch
┆ ⇝ .nightstars
┆ ⇝ .papercutstyle
┆ ⇝ .pig
┆ ⇝ .pixelglitch
┆ ⇝ .pubg
┆ ⇝ .royaltext
┆ ⇝ .sandsummer
┆ ⇝ .summerbeach
┆ ⇝ .sunlight
┆ ⇝ .typographytext
┆ ⇝ .underwatertext
┆ ⇝ .watercolortext
┆ ⇝ .wood
┆ ⇝ .writetext
┆ ⇝ .ytgoldbutton
┆ ⇝ .ytsilverbutton
┆ ⇝ .resize
┆ ⇝ .kompres
╰➤-------------------------------
`
global.menurpg = `
╭➤--「RPG GAME MENU 」
┆ ⇝ .adopsipet
┆ ⇝ .attack
┆ ⇝ .begal
┆ ⇝ .berkebun
┆ ⇝ .buatstreak
┆ ⇝ .buy
┆ ⇝ .claim
┆ ⇝ .cekpasangan
┆ ⇝ .craft
┆ ⇝ .daftar
┆ ⇝ .daily
┆ ⇝ .dungeon
┆ ⇝ .equip
┆ ⇝ .ewepaksa
┆ ⇝ .flee
┆ ⇝ .foraging
┆ ⇝ .hapusstreak
┆ ⇝ .infopet
┆ ⇝ .inventory
┆ ⇝ .isidompet
┆ ⇝ .item
┆ ⇝ .jobkerja
┆ ⇝ .judionline
┆ ⇝ .kerja
┆ ⇝ .leaderboardrpg
┆ ⇝ .limit
┆ ⇝ .maling
┆ ⇝ .mancing
┆ ⇝ .mancingstart
┆ ⇝ .me
┆ ⇝ .meramu
┆ ⇝ .mining
┆ ⇝ .moonly
┆ ⇝ .ngaji
┆ ⇝ .ngelonte
┆ ⇝ .ngocok
┆ ⇝ .ngojek
┆ ⇝ .nyalainstreak
┆ ⇝ .openbo
┆ ⇝ .profile
┆ ⇝ .putus
┆ ⇝ .putuspaksa
┆ ⇝ .pvp
┆ ⇝ .quest
┆ ⇝ .rpgexplore
┆ ⇝ .rpghelp
┆ ⇝ .rpginv
┆ ⇝ .rpgmove
┆ ⇝ .rpgshop
┆ ⇝ .rpgstart
┆ ⇝ .rpgstats
┆ ⇝ .sell
┆ ⇝ .skill
┆ ⇝ .slot
┆ ⇝ .spacegame
┆ ⇝ .streak
┆ ⇝ .tambang
┆ ⇝ .tfgold
┆ ⇝ .trading
┆ ⇝ .tembak
┆ ⇝ .toplevel
┆ ⇝ .topstreak
┆ ⇝ .unreg
┆ ⇝ .use
┆ ⇝ .weekly
┆ ⇝ .yearly
╰➤-------------------------------
`
global.menugame = ` 
╭➤--「GAME MENU 」
┆ ⇝ .tictactoe
┆ ⇝ .kuismath
┆ ⇝ .sambungkata
┆ ⇝ .sambungkata2
┆ ⇝ .tebakhero
┆ ⇝ .tebakgenshin
┆ ⇝ .asahotak
┆ ⇝ .bom
┆ ⇝ .caklontong
┆ ⇝ .family100
┆ ⇝ .kuis
┆ ⇝ .lengkapikalimat
┆ ⇝ .siapakahaku
┆ ⇝ .susunkata
┆ ⇝ .tebakanime
┆ ⇝ .tebakbendera
┆ ⇝ .tebakff
┆ ⇝ .tebakgame
┆ ⇝ .tebakgambar
┆ ⇝ .tebakhewan
┆ ⇝ .tebakinggris
┆ ⇝ .tebakjkt
┆ ⇝ .tebakjorok
┆ ⇝ .tebakkah
┆ ⇝ .tebakkalimat
┆ ⇝ .tebakkata
┆ ⇝ .tebaklagu
┆ ⇝ .tebaklirik
┆ ⇝ .tebaklogo
┆ ⇝ .tebakmakanan
┆ ⇝ .tekateki
╰➤-------------------------------
`
global.menusearch = `
╭➤--「SEARCH MENU 」
┆ ⇝ .animeinfo
┆ ⇝ .carigrupwa
┆ ⇝ .caristiker
┆ ⇝ .cekgempa
┆ ⇝ .cekkalender
┆ ⇝ .cekml
┆ ⇝ .ceksim
┆ ⇝ .cekcuaca
┆ ⇝ .ceknsfw
┆ ⇝ .cekjadwal
┆ ⇝ .charinfo
┆ ⇝ .chord
┆ ⇝ .chstalk
┆ ⇝ .cnbc
┆ ⇝ .cnn
┆ ⇝ .stalkgithub
┆ ⇝ .gsmarena
┆ ⇝ .hiitwixtor
┆ ⇝ .igstalk
┆ ⇝ .lirik
┆ ⇝ .myanimelist
┆ ⇝ .npmjs
┆ ⇝ .otakudesu
┆ ⇝ .pinterest/pin
┆ ⇝ .play
┆ ⇝ .playch
┆ ⇝ .playtiktok
┆ ⇝ .playv2
┆ ⇝ .playvid
┆ ⇝ .ppcouple
┆ ⇝ .ptv
┆ ⇝ .searchanime
┆ ⇝ .searchchar
┆ ⇝ .searchgame
┆ ⇝ .soundcloud
┆ ⇝ .spotify
┆ ⇝ .stalkroblox
┆ ⇝ .tiktokstalk
┆ ⇝ .wastalk
┆ ⇝ .wattpad
┆ ⇝ .whatmusik
┆ ⇝ .xnxxsearch 🅟
┆ ⇝ .yts
╰➤-------------------------------
`
global.menudownlod = ` 
╭➤--「DOWNLOAD MENU 」
┆ ⇝ .capcut
┆ ⇝ .douyin / .dy
┆ ⇝ .elainadl support all link
┆ ⇝ .facebook
┆ ⇝ .gdrive
┆ ⇝ .gitclone
┆ ⇝ .instagram
┆ ⇝ .likee / .lk
┆ ⇝ .mediafire
┆ ⇝ .pastebin
┆ ⇝ .pindl
┆ ⇝ .pinterest
┆ ⇝ .play1
┆ ⇝ .snackvideo / .sv
┆ ⇝ .spdown
┆ ⇝ .telesticker
┆ ⇝ .threads / .thds
┆ ⇝ .tiktok
┆ ⇝ .tiktokslide
┆ ⇝ .tiktokmp3
┆ ⇝ .twitter
┆ ⇝ .videy / .vd
┆ ⇝ .xnxxdownload 🅟
┆ ⇝ .ytmp3
┆ ⇝ .ytmp4
╰➤-------------------------------
`
global.menuai = ` 
╭➤--「AI MENU 」
┆ ⇝ .ai
┆ ⇝ .airealtime
┆ ⇝ .allam
┆ ⇝ .autoai
┆ ⇝ .bard
┆ ⇝ .customai
┆ ⇝ .deepseek
┆ ⇝ .deepseekart
┆ ⇝ .gemini
┆ ⇝ .gpt5plus 🅟
┆ ⇝ .groq
┆ ⇝ .hyperai
┆ ⇝ .joey
┆ ⇝ .logicbell
┆ ⇝ .nano
┆ ⇝ .openai
┆ ⇝ .powerbrain
┆ ⇝ .publicai
┆ ⇝ .soraai 🅟
┆ ⇝ .venice
┆ ⇝ .webpilot
╰➤-------------------------------
`
global.menufun = `
╭➤--「FUN MENU 」
┆ ⇝ .afk
┆ ⇝ .artinama
┆ ⇝ .cekbeban
┆ ⇝ .cekbucin
┆ ⇝ .cekfemboy
┆ ⇝ .cekgay
┆ ⇝ .cekhobi
┆ ⇝ .cekjodoh
┆ ⇝ .cekjones
┆ ⇝ .cekkaya
┆ ⇝ .cekkodam
┆ ⇝ .cekkontol
┆ ⇝ .ceklesbi
┆ ⇝ .cekmasadepan
┆ ⇝ .cekmemek
┆ ⇝ .ceksange
┆ ⇝ .cekstress
┆ ⇝ .cekwibu
┆ ⇝ .fakeml
┆ ⇝ .fakexnxx
┆ ⇝ .faktadunia
┆ ⇝ .faktaunik
┆ ⇝ .infonegara
┆ ⇝ .jumlahuser
┆ ⇝ .kecocokanpasangan
┆ ⇝ .kirimch
┆ ⇝ .meme
┆ ⇝ .pakustad
┆ ⇝ .planet
┆ ⇝ .readmore
┆ ⇝ .sertifikattolol
┆ ⇝ .tafsirmimpi
┆ ⇝ .waifu
╰➤-------------------------------
`
global.menuprimbon = `
╭➤--「PRIMBON MENU 」
┆ ⇝ .apakah
┆ ⇝ .artinama
┆ ⇝ .bagaimanakah
┆ ⇝ .bisakah
┆ ⇝ .bacot
┆ ⇝ .bucinhacker
┆ ⇝ .bucinjs
┆ ⇝ .cekaura
┆ ⇝ .cekmemek
┆ ⇝ .ceksial
┆ ⇝ .ceksifat
┆ ⇝ .darkjokes
┆ ⇝ .dilan
┆ ⇝ .isidompet
┆ ⇝ .jodohmakanan
┆ ⇝ .kapan
┆ ⇝ .kecocokannama
┆ ⇝ .nasibbatere
┆ ⇝ .nomerhoki
┆ ⇝ .pantun
┆ ⇝ .profesiku
┆ ⇝ .quotes
┆ ⇝ .quotesanime
┆ ⇝ .quotesbucin
┆ ⇝ .quotesgalau
┆ ⇝ .quotesjawa
┆ ⇝ .quotessenja
┆ ⇝ .quotessunda
┆ ⇝ .ngawur
┆ ⇝ .nyindir
┆ ⇝ .ramalancinta
┆ ⇝ .ramalanjodoh
┆ ⇝ .ramalanjodohbali
┆ ⇝ .ramalannasib
┆ ⇝ .rate
┆ ⇝ .scankontol
┆ ⇝ .scanmemek
┆ ⇝ .suamiistri
┆ ⇝ .wangy
┆ ⇝ .zodiak
╰➤-------------------------------
`
global.menumaker = `
╭➤--「MAKER MENU 」
┆ ⇝ .fakedev1-3
┆ ⇝ .luma
┆ ⇝ .photoai
┆ ⇝ .fakektp
┆ ⇝ .carbon
┆ ⇝ .tofigure 
┆ ⇝ .telanjang 🅟
┆ ⇝ .fakestory
┆ ⇝ .tosunda 🅟
┆ ⇝ .tojawa 
┆ ⇝ .hijabpin 
┆ ⇝ .hitamin
┆ ⇝ .todonghua 🅟
┆ ⇝ .tomanhwa 🅟
┆ ⇝ .toanime 🅟
┆ ⇝ .tomanga 🅟
┆ ⇝ .topenjara 
┆ ⇝ .elainaedit 🅟
┆ ⇝ .putihkan 🅟
┆ ⇝ .aiedit 🅟
┆ ⇝ .banana 🅟
┆ ⇝ .sdm 🅟
┆ ⇝ .tomoai
┆ ⇝ .topacar
┆ ⇝ .tomonyet
┆ ⇝ .tosatan
┆ ⇝ .toroblox
┆ ⇝ .topunk
┆ ⇝ .tomangu
┆ ⇝ .tosad
┆ ⇝ .todpr
┆ ⇝ .tobabi
┆ ⇝ .buatgambar
┆ ⇝ .buatlagu 🅟
┆ ⇝ .buatvideo 🅟
┆ ⇝ .ghibli 🅟
┆ ⇝ .tobotak 🅟
┆ ⇝ .tochibi 🅟
┆ ⇝ .todino 🅟
┆ ⇝ .jadidisney
┆ ⇝ .jadigta
┆ ⇝ .jadipixar
┆ ⇝ .nglspam 🅟
┆ ⇝ .polaroid 🅟
┆ ⇝ .tofootball 🅟
┆ ⇝ .tokartun 🅟
┆ ⇝ .veo3 🅟
┆ ⇝ .zrooart
┆ ⇝ .toalbino
┆ ⇝ .tospiderman
┆ ⇝ .tonaruto
┆ ⇝ .tobatman
┆ ⇝ .tosuperman
┆ ⇝ .toironman
┆ ⇝ .tocaptainamerica
┆ ⇝ .tothor
┆ ⇝ .tohulk
┆ ⇝ .towolverine
┆ ⇝ .todeadpool
┆ ⇝ .toflash
┆ ⇝ .toaquaman
┆ ⇝ .tocyan
┆ ⇝ .tovision
┆ ⇝ .toblackpanther
┆ ⇝ .tostarlord
┆ ⇝ .togroot
┆ ⇝ .torocket
┆ ⇝ .todracula
┆ ⇝ .tofrankenstein
┆ ⇝ .towerewolf
┆ ⇝ .tozombie
┆ ⇝ .tovampire
┆ ⇝ .toghost
┆ ⇝ .toskeleton
┆ ⇝ .todevil
┆ ⇝ .toangel
┆ ⇝ .tofairy
┆ ⇝ .towizard
┆ ⇝ .towinged
┆ ⇝ .toelf
┆ ⇝ .todwarf
┆ ⇝ .toorc
┆ ⇝ .totroll
┆ ⇝ .togiant
┆ ⇝ .tominotaur
┆ ⇝ .tomedusa
┆ ⇝ .tocentaur
┆ ⇝ .togriffin
┆ ⇝ .tophoenix
┆ ⇝ .todragon
┆ ⇝ .tounicorn
┆ ⇝ .topeacock
┆ ⇝ .towolf
┆ ⇝ .tofox
┆ ⇝ .tobear
┆ ⇝ .tolion
┆ ⇝ .totiger
┆ ⇝ .topanda
┆ ⇝ .tokoala
┆ ⇝ .topenguin
┆ ⇝ .toowl
┆ ⇝ .toeagle
┆ ⇝ .tofalcon
┆ ⇝ .toraven
┆ ⇝ .tocrow
┆ ⇝ .tosnake
┆ ⇝ .toshark
┆ ⇝ .tocrocodile
┆ ⇝ .tooctopus
┆ ⇝ .tojellyfish
┆ ⇝ .tostarfish
┆ ⇝ .toseahorse
┆ ⇝ .todolphin
┆ ⇝ .towhale
┆ ⇝ .torobot
┆ ⇝ .tocyborg
┆ ⇝ .toandroid
┆ ⇝ .toalien
┆ ⇝ .toufo
┆ ⇝ .toastronaut
┆ ⇝ .tocosmonaut
┆ ⇝ .toscuba
┆ ⇝ .todiver
┆ ⇝ .topirate
┆ ⇝ .tocowboy
┆ ⇝ .toninja
┆ ⇝ .tosamurai
┆ ⇝ .toviking
┆ ⇝ .toknight
┆ ⇝ .toarcher
┆ ⇝ .tomage
┆ ⇝ .tocleric
┆ ⇝ .tobard
┆ ⇝ .torogue
┆ ⇝ .tomonk
┆ ⇝ .tobarbarian
┆ ⇝ .tonecromancer
┆ ⇝ .todruid
┆ ⇝ .toranger
┆ ⇝ .topaladin
┆ ⇝ .togunslinger
┆ ⇝ .tomechanic
┆ ⇝ .toscientist
┆ ⇝ .todoctor
┆ ⇝ .toengineer
┆ ⇝ .toartist
┆ ⇝ .tosinger
┆ ⇝ .todancer
┆ ⇝ .toactor
┆ ⇝ .todirector
┆ ⇝ .towriter
┆ ⇝ .tophotographer
┆ ⇝ .tochef
┆ ⇝ .tobaker
┆ ⇝ .tobarista
┆ ⇝ .tobartender
┆ ⇝ .topilot
┆ ⇝ .todriver
┆ ⇝ .tosailor
┆ ⇝ .tosoldier
┆ ⇝ .topoliceman
┆ ⇝ .tofirefighter
┆ ⇝ .toteacher
┆ ⇝ .toprofessor
┆ ⇝ .tostudent
┆ ⇝ .toprogrammer
┆ ⇝ .todesigner
┆ ⇝ .totester
┆ ⇝ .tomanager
┆ ⇝ .toboss
┆ ⇝ .toceo
┆ ⇝ .tocfo
┆ ⇝ .tocoo
┆ ⇝ .tocmo
┆ ⇝ .tocto
┆ ⇝ .tocpo
┆ ⇝ .tocko
┆ ⇝ .toclown
┆ ⇝ .tomime
┆ ⇝ .tojester
┆ ⇝ .tomagician
┆ ⇝ .toillusionist
┆ ⇝ .toescapeartist
┆ ⇝ .toacrobat
┆ ⇝ .tocontortionist
┆ ⇝ .toswordswallower
┆ ⇝ .tofirebreather
┆ ⇝ .tojugger
┆ ⇝ .tounicyclist
┆ ⇝ .totightrope
┆ ⇝ .totrapeze
┆ ⇝ .toaerialist
┆ ⇝ .tocannon
┆ ⇝ .tostilts
┆ ⇝ .tomask
┆ ⇝ .tomummy
┆ ⇝ .tozorro
┆ ⇝ .tosherlock
┆ ⇝ .tophantom
┆ ⇝ .todraco
┆ ⇝ .tohannibal
┆ ⇝ .tojoker
┆ ⇝ .tovenom
┆ ⇝ .tocarnage
┆ ⇝ .togreen
┆ ⇝ .tolizard
┆ ⇝ .torhino
┆ ⇝ .tovulture
┆ ⇝ .toelectro
┆ ⇝ .tosandman
┆ ⇝ .tomysterio
┆ ⇝ .togoblin
┆ ⇝ .tochemo
┆ ⇝ .toloki
┆ ⇝ .tothanos
┆ ⇝ .togalactus
┆ ⇝ .togantungan
┆ ⇝ .todarkseid
┆ ⇝ .tobrainiac
┆ ⇝ .todoomsday
┆ ⇝ .tobizarro
┆ ⇝ .tometallo
┆ ⇝ .toparasite
┆ ⇝ .togrodd
┆ ⇝ .tocircus
┆ ⇝ .toreverse
┆ ⇝ .tomirror
┆ ⇝ .togold
┆ ⇝ .tosilver
┆ ⇝ .tobronze
┆ ⇝ .tocopper
┆ ⇝ .tosteel
┆ ⇝ .tocarbon
┆ ⇝ .tocrystal
┆ ⇝ .todiamond
┆ ⇝ .tosapphire
┆ ⇝ .toruby
┆ ⇝ .toemerald
┆ ⇝ .totopaz
┆ ⇝ .toamethyst
┆ ⇝ .toopal
┆ ⇝ .toperidot
┆ ⇝ .toaquamarine
┆ ⇝ .tocitrine
┆ ⇝ .totourmaline
┆ ⇝ .togarnet
┆ ⇝ .tospinel
┆ ⇝ .tozircon
┆ ⇝ .totanzanite
┆ ⇝ .toiolite
┆ ⇝ .tohematite
┆ ⇝ .tomoonstone
┆ ⇝ .tosunstone
┆ ⇝ .tostarstone
┆ ⇝ .tocomet
┆ ⇝ .tometeor
┆ ⇝ .toasteroid
┆ ⇝ .tonebula
┆ ⇝ .togalaxy
┆ ⇝ .touniverse
┆ ⇝ .toblackhole
┆ ⇝ .towormhole
┆ ⇝ .toportal
┆ ⇝ .totime
┆ ⇝ .tospace
┆ ⇝ .todimension
┆ ⇝ .toparallel
┆ ⇝ .toalternate
┆ ⇝ .tomultiverse
┆ ⇝ .tomegaverse
┆ ⇝ .tometaverse
┆ ⇝ .toomniverse
╰➤-------------------------------
`
global.menutolls = ` 
╭➤--「TOOLS MENU 」
┆ ⇝ .ai
┆ ⇝ .aitts
┆ ⇝ .ambilsw
┆ ⇝ .copilotvoice
┆ ⇝ .donate
┆ ⇝ .enc 🅟
┆ ⇝ .enchard 🅟
┆ ⇝ .fakecall
┆ ⇝ .fakedana
┆ ⇝ .getpp
┆ ⇝ .gptimg
┆ ⇝ .gptonline
┆ ⇝ .hd
┆ ⇝ .hdvid 🅟
┆ ⇝ .iqc
┆ ⇝ .iqc2
┆ ⇝ .kapanreset
┆ ⇝ .lobbyffmax
┆ ⇝ .ngl
┆ ⇝ .nulis
┆ ⇝ .ocr 🅟
┆ ⇝ .ptvch
┆ ⇝ .rch
┆ ⇝ .rvo 🅟
┆ ⇝ .shortlink
┆ ⇝ .shortlink2
┆ ⇝ .sidompul
┆ ⇝ .speech2text
┆ ⇝ .ssweb
┆ ⇝ .sswebhp
┆ ⇝ .struk
┆ ⇝ .tempo
┆ ⇝ .texttosound
┆ ⇝ .togif
┆ ⇝ .tomp3
┆ ⇝ .tourl
┆ ⇝ .tourl2 🅟
┆ ⇝ .tourl3
┆ ⇝ .tovn
┆ ⇝ .translate
┆ ⇝ .ttsbrando
┆ ⇝ .vocalremover
┆ ⇝ .voicecover 🅟
┆ ⇝ .ytsummarizer
╰➤-------------------------------
`
global.menusticker = `
╭➤--「STICKERS MENU 」
┆ ⇝ .brat
┆ ⇝ .brathd
┆ ⇝ .bradvid
┆ ⇝ .bratanime
┆ ⇝ .bratbahlil
┆ ⇝ .bratgura
┆ ⇝ .bratgambar
┆ ⇝ .bratpink
┆ ⇝ .ytcomment
┆ ⇝ .bratvid
┆ ⇝ .emoji
┆ ⇝ .emojifacebook
┆ ⇝ .emojigoogle
┆ ⇝ .emojiiphone
┆ ⇝ .emojigif
┆ ⇝ .emojimix
┆ ⇝ .emojimicrosoft
┆ ⇝ .emojipixel
┆ ⇝ .emojiopen
┆ ⇝ .emojitwitter
┆ ⇝ .manusialidi
┆ ⇝ .qc
┆ ⇝ .smeme
┆ ⇝ .sticker
┆ ⇝ .stickerpatrick
┆ ⇝ .stickerpatrickgif
┆ ⇝ .stickerspongebob
┆ ⇝ .stickerpentol
┆ ⇝ .stickerbucin
┆ ⇝ .stikeranime
┆ ⇝ .stikerdinokuning
┆ ⇝ .stikergojo
┆ ⇝ .stikermukalu
┆ ⇝ .stikerpentol
┆ ⇝ .stikerrandom
┆ ⇝ .stikerspongebob
┆ ⇝ .swm 🅟
┆ ⇝ .toimg
┆ ⇝ .tvstiker
╰➤-------------------------------
`
global.menuenc = `
╭➤--「 ENCRYPT MENU 」
┆ ⇝ .enccustom <nama>
┆ ⇝ .encinvis
┆ ⇝ .encsiu
┆ ⇝ .encstrong
┆ ⇝ .encultra
┆ ⇝ .enchard 🅟
┆ ⇝ .enc 🅟
┆ ⇝ .encryptcustom <nama>
┆ ⇝ .encryptinvis
┆ ⇝ .encryptsiu
┆ ⇝ .encryptstrong
┆ ⇝ .encryptultra
┆ ⇝ .customenc <nama>
┆ ⇝ .invisenc
┆ ⇝ .siuenc
┆ ⇝ .strongenc
┆ ⇝ .ultraenc
┆ ⇝ .custom-encrypt <nama>
┆ ⇝ .invis-encrypt
┆ ⇝ .siu-encrypt
┆ ⇝ .strong-encrypt
┆ ⇝ .ultra-encrypt
┆ ⇝ .enc-custom <nama>
┆ ⇝ .enc-invis
┆ ⇝ .enc-siu
┆ ⇝ .enc-strong
┆ ⇝ .enc-ultra
┆ ⇝ .enccustomjs <nama>
┆ ⇝ .encinvisible
┆ ⇝ .encryptinvisible
┆ ⇝ .invisibleenc
┆ ⇝ .invisible-encrypt
┆ ⇝ .enc-invisible
┆ ⇝ .eninvisiblejs
┆ ⇝ .jsinvisenc
┆ ⇝ .encjsinvis
┆ ⇝ .encsiujs
┆ ⇝ .jssiuenc
┆ ⇝ .siujsen
┆ ⇝ .encstrongjs
┆ ⇝ .jsstrongenc
┆ ⇝ .strongjsen
┆ ⇝ .encultrajs
┆ ⇝ .jsultraenc
┆ ⇝ .ultrajsen
┆ ⇝ .encryptcustomjs <nama>
┆ ⇝ .customjsen <nama>
╰➤-------------------------------
`
global.allmenu = `
${global.menusticker}\n${global.menumaker}\n${global.menustk}\n${global.menutolls}\n${global.menuehpoto}\n${global.menudownlod}\n${global.menuai}\n${global.menusearch}\n${global.menuprimbon}\n${global.menufun}\n${global.menugame}\n${global.menurpg}\n${global.menuislam}\n${global.menucecan}\n${global.menunsfw}\n${global.menugroup}\n${global.menustore}\n${global.menupanel}\n${global.menuenc}\n${global.menuowner}
`

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});